"""Animals: pigs, cows, chickens and cats.

Models are written the way the real game writes them — boxes in model pixels
with a texture offset, hung from pivots, Y pointing down and the front at -Z —
so the game's own entity textures (assets/entity) wrap onto them unchanged.
A box's six faces are cut from the texture in the standard net:

        [top][bottom]
    [side][front][side][back]

Behaviour is deliberately simple: wander, idle, panic when hit, swim, step up
one block, and despawn when the player is far away.
"""

import math
import os
import random

import glm
import moderngl as mgl
import numpy as np
import pygame as pg

from world.blocks import COLLIDES
from world.modern_chunk import WATER

HALF_PI = math.pi / 2

# ---------------------------------------------------------------------------
# Models: kind -> texture size, parts. A part is
#     (name, pivot (x, y, z), [boxes], x rotation)
# and a box is (x, y, z, w, h, d, u, v) in model pixels.
# ---------------------------------------------------------------------------

def _legs(u, v, box, pivots):
    return [(f'leg{i}', p, [box + (u, v)], 0.0) for i, p in enumerate(pivots)]


MODELS = {
    'pig': {
        'tex': (64, 64), 'size': (0.9, 0.9), 'health': 10, 'speed': 1.1, 'scale': 1.0,
        'parts': [
            ('head', (0, 12, -6), [(-4, -4, -8, 8, 8, 8, 0, 0),
                                   (-2, 0, -9, 4, 3, 1, 16, 16)], 0.0),
            ('body', (0, 11, 2), [(-5, -10, -7, 10, 16, 8, 28, 8)], HALF_PI),
        ] + _legs(0, 16, (-2, 0, -2, 4, 6, 4),
                  [(-3, 18, 7), (3, 18, 7), (-3, 18, -5), (3, 18, -5)]),
    },
    'cow': {
        'tex': (64, 64), 'size': (0.9, 1.4), 'health': 10, 'speed': 1.0, 'scale': 1.0,
        'parts': [
            ('head', (0, 4, -8), [(-4, -4, -6, 8, 8, 6, 0, 0),
                                  (-5, -5, -4, 1, 3, 1, 22, 0),
                                  (4, -5, -4, 1, 3, 1, 22, 0)], 0.0),
            ('body', (0, 5, 2), [(-6, -10, -7, 12, 18, 10, 18, 4),
                                 (-2, 2, -8, 4, 6, 1, 52, 0)], HALF_PI),
        ] + _legs(0, 16, (-2, 0, -2, 4, 12, 4),
                  [(-4, 12, 7), (4, 12, 7), (-4, 12, -6), (4, 12, -6)]),
    },
    'chicken': {
        'tex': (64, 32), 'size': (0.4, 0.7), 'health': 4, 'speed': 1.0, 'scale': 1.0,
        'parts': [
            ('head', (0, 15, -4), [(-2, -6, -2, 4, 6, 3, 0, 0),
                                   (-2, -4, -4, 4, 2, 2, 14, 0),
                                   (-1, -2, -3, 2, 2, 2, 14, 4)], 0.0),
            ('body', (0, 16, 0), [(-3, -4, -3, 6, 8, 6, 0, 9)], HALF_PI),
            ('leg0', (-2, 19, 1), [(-1, 0, -3, 3, 5, 3, 26, 0)], 0.0),
            ('leg1', (1, 19, 1), [(-1, 0, -3, 3, 5, 3, 26, 0)], 0.0),
            ('wing0', (-4, 13, 0), [(0, 0, -3, 1, 4, 6, 24, 13)], 0.0),
            ('wing1', (4, 13, 0), [(-1, 0, -3, 1, 4, 6, 24, 13)], 0.0),
        ],
    },
    'cat': {
        'tex': (64, 32), 'size': (0.6, 0.7), 'health': 10, 'speed': 1.3, 'scale': 0.8,
        'parts': [
            ('head', (0, 15, -9), [(-2.5, -2, -3, 5, 4, 5, 0, 0),
                                   (-1.5, 0, -4, 3, 2, 2, 0, 24),
                                   (-2, -3, 0, 1, 1, 2, 0, 10),
                                   (1, -3, 0, 1, 1, 2, 6, 10)], 0.0),
            ('body', (0, 12, -10), [(-2, 3, -8, 4, 16, 6, 20, 0)], HALF_PI),
            ('tail1', (0, 15, 8), [(-0.5, 0, 0, 1, 8, 1, 0, 15)], 0.9),
            ('tail2', (0, 20, 14), [(-0.5, 0, 0, 1, 8, 1, 4, 15)], 1.73),
            ('leg0', (1.1, 18, 5), [(-1, 0, 1, 2, 6, 2, 8, 13)], 0.0),
            ('leg1', (-1.1, 18, 5), [(-1, 0, 1, 2, 6, 2, 8, 13)], 0.0),
            ('leg2', (1.2, 14.1, -5), [(-1, 0, 0, 2, 10, 2, 40, 0)], 0.0),
            ('leg3', (-1.2, 14.1, -5), [(-1, 0, 0, 2, 10, 2, 40, 0)], 0.0),
        ],
    },
}

SPAWN_WEIGHTS = (('pig', 10), ('cow', 8), ('chicken', 10), ('cat', 2))
MAX_MOBS = 16
SPAWN_MIN, SPAWN_MAX = 20, 52        # blocks from the player
DESPAWN = 110
CAT_SKINS = ('tabby', 'black', 'red', 'siamese', 'british_shorthair', 'calico',
             'persian', 'ragdoll', 'white', 'jellie', 'all_black')

COLD = ('Snow', 'Frozen', 'Ice', 'Taiga', 'Grove', 'Peak', 'Windswept')
WARM = ('Desert', 'Savanna', 'Badlands', 'Jungle', 'Mangrove', 'Mesa')


def _box_faces(x, y, z, w, h, d, u, v):
    """Six quads of one box: (corners, uvs, shade). Model space, Y down."""
    x0, x1, y0, y1, z0, z1 = x, x + w, y, y + h, z, z + d
    return (
        # top (smallest y is up once flipped)
        (((x0, y0, z1), (x1, y0, z1), (x1, y0, z0), (x0, y0, z0)),
         ((u + d, v), (u + d + w, v), (u + d + w, v + d), (u + d, v + d)), 1.0),
        # bottom
        (((x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)),
         ((u + d + w, v), (u + d + 2 * w, v), (u + d + 2 * w, v + d), (u + d + w, v + d)), 0.5),
        # front (-Z)
        (((x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)),
         ((u + d, v + d), (u + d + w, v + d), (u + d + w, v + d + h), (u + d, v + d + h)), 0.85),
        # side at x0
        (((x0, y0, z1), (x0, y0, z0), (x0, y1, z0), (x0, y1, z1)),
         ((u, v + d), (u + d, v + d), (u + d, v + d + h), (u, v + d + h)), 0.7),
        # side at x1
        (((x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)),
         ((u + d + w, v + d), (u + 2 * d + w, v + d), (u + 2 * d + w, v + d + h), (u + d + w, v + d + h)), 0.7),
        # back (+Z)
        (((x1, y0, z1), (x0, y0, z1), (x0, y1, z1), (x1, y1, z1)),
         ((u + 2 * d + w, v + d), (u + 2 * d + 2 * w, v + d), (u + 2 * d + 2 * w, v + d + h), (u + 2 * d + w, v + d + h)), 0.85),
    )


def _part_mesh(boxes, tex_w, tex_h):
    out = []
    for box in boxes:
        for corners, uvs, shade in _box_faces(*box):
            for i in (0, 1, 2, 0, 2, 3):
                cx, cy, cz = corners[i]
                tu, tv = uvs[i]
                out += [cx, cy, cz, tu / tex_w, tv / tex_h, shade]
    return np.array(out, dtype='f4')


# Model pixels -> blocks, Y flipped, 24 px of model height = the ground.
MODEL_TO_WORLD = glm.translate(glm.vec3(0, 1.5, 0)) * glm.scale(glm.vec3(-1 / 16, -1 / 16, 1 / 16))


class Mob:
    def __init__(self, kind, texture, x, y, z):
        m = MODELS[kind]
        self.kind, self.texture = kind, texture
        self.pos = glm.vec3(x, y, z)
        self.vel = glm.vec3(0.0)
        self.yaw = random.uniform(0, 2 * math.pi)
        self.target_yaw = self.yaw
        self.head_yaw = 0.0
        self.walking = False
        self.timer = random.uniform(1.0, 4.0)
        self.on_ground = False
        self.limb = 0.0          # how far the legs have swung, total
        self.limb_amount = 0.0
        self.health = m['health']
        self.hurt = 0.0
        self.panic = 0.0
        self.dead = 0.0          # seconds since death; > 0 means dying
        self.half = m['size'][0] / 2
        self.height = m['size'][1]
        self.speed = m['speed']
        self.flap = 0.0

    def forward(self):
        return glm.vec3(-math.sin(self.yaw), 0.0, -math.cos(self.yaw))


class Entities:
    def __init__(self, renderer, world):
        self.renderer = renderer
        self.world = world               # the chunk manager: get_block_at
        self.ctx = renderer.ctx
        sm = renderer.shader_manager
        self.prog = sm.get_program('entity') or sm.load_shader(
            'entity', 'shaders/entity.vert', 'shaders/entity.frag')
        self.mobs = []
        self.spawn_clock = 0.0
        self.textures = {}
        self.parts = {}                  # kind -> [(name, pivot, xrot, vao, count)]
        self.enabled = True
        if self.prog is None:
            self.enabled = False
            return
        for kind, m in MODELS.items():
            tw, th = m['tex']
            parts = []
            for name, pivot, boxes, xrot in m['parts']:
                data = _part_mesh(boxes, tw, th)
                vbo = self.ctx.buffer(data.tobytes())
                vao = self.ctx.vertex_array(self.prog, [(vbo, '3f 2f 1f', 'in_position', 'in_uv', 'in_shade')])
                parts.append((name, glm.vec3(pivot), xrot, vao, vbo))
            self.parts[kind] = parts

    # ------------------------------------------------------------------
    def texture(self, path):
        tex = self.textures.get(path)
        if tex is None:
            try:
                surf = pg.image.load(path)
                tex = self.ctx.texture(surf.get_size(), 4, pg.image.tostring(surf, 'RGBA'))
            except (pg.error, FileNotFoundError):
                tex = None
            if tex is not None:
                tex.filter = (mgl.NEAREST, mgl.NEAREST)
            self.textures[path] = tex
        return tex

    def release(self):
        for parts in self.parts.values():
            for _, _, _, vao, vbo in parts:
                vao.release()
                vbo.release()
        for tex in self.textures.values():
            if tex:
                tex.release()
        self.parts = {}
        self.textures = {}

    # ------------------------------------------------------------------
    # World queries
    # ------------------------------------------------------------------
    def solid(self, x, y, z):
        return bool(COLLIDES[self.world.get_block_at(math.floor(x), math.floor(y), math.floor(z))])

    def blocked(self, mob, x, z):
        """Would the mob's body overlap a solid block standing at (x, z)?"""
        h = mob.half
        y0 = math.floor(mob.pos.y + 0.05)
        y1 = math.floor(mob.pos.y + mob.height - 0.05)
        for cx in (x - h, x + h):
            for cz in (z - h, z + h):
                for y in range(y0, y1 + 1):
                    if self.solid(cx, y, cz):
                        return True
        return False

    # ------------------------------------------------------------------
    # Spawning
    # ------------------------------------------------------------------
    def try_spawn(self, player, biome_name_at):
        alive = [m for m in self.mobs if not m.dead]
        if len(alive) >= MAX_MOBS:
            return
        a = random.uniform(0, 2 * math.pi)
        r = random.uniform(SPAWN_MIN, SPAWN_MAX)
        x = math.floor(player.x + math.cos(a) * r)
        z = math.floor(player.z + math.sin(a) * r)
        chunk = self.world.get_chunk(x // 16, z // 16)
        if chunk is None:
            return
        y = None
        for yy in range(min(250, int(player.y) + 40), 2, -1):
            b = self.world.get_block_at(x, yy, z)
            if COLLIDES[b]:
                if b in (1, 128) and not COLLIDES[self.world.get_block_at(x, yy + 1, z)] \
                        and not COLLIDES[self.world.get_block_at(x, yy + 2, z)]:
                    y = yy + 1
                break
            if b == WATER:
                break
        if y is None:
            return
        kinds, weights = zip(*SPAWN_WEIGHTS)
        kind = random.choices(kinds, weights)[0]
        biome = biome_name_at(x, z)
        climate = ('cold' if any(w in biome for w in COLD) else
                   'warm' if any(w in biome for w in WARM) else 'temperate')
        for _ in range(1 if kind == 'cat' else random.randint(2, 4)):
            ox, oz = random.uniform(-2, 2), random.uniform(-2, 2)
            path = self.skin(kind, climate)
            if path:
                self.mobs.append(Mob(kind, path, x + 0.5 + ox, y + 0.1, z + 0.5 + oz))

    def skin(self, kind, climate):
        base = os.path.join('assets', 'entity', kind)
        if kind == 'cat':
            names = [f'cat_{s}.png' for s in CAT_SKINS]
            random.shuffle(names)
        else:
            # The cold pig's texture is laid out for a furrier model than this
            # one, so a cold-biome pig wears the temperate skin.
            if kind == 'pig' and climate == 'cold':
                climate = 'temperate'
            names = [f'{kind}_{climate}.png', f'{kind}_temperate.png']
        for n in names:
            p = os.path.join(base, n)
            if os.path.exists(p):
                return p
        return None

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------
    def update(self, dt, player, biome_name_at, spawn=True):
        if not self.enabled:
            return
        if spawn:
            self.spawn_clock -= dt
            if self.spawn_clock <= 0:
                self.spawn_clock = 1.5
                self.try_spawn(player, biome_name_at)

        keep = []
        for m in self.mobs:
            dx, dz = m.pos.x - player.x, m.pos.z - player.z
            if dx * dx + dz * dz > DESPAWN * DESPAWN:
                continue
            if m.dead:
                m.dead += dt
                if m.dead < 1.0:
                    keep.append(m)
                continue
            if self.world.get_chunk(math.floor(m.pos.x) // 16, math.floor(m.pos.z) // 16) is None:
                keep.append(m)           # frozen until its chunk is back
                continue
            self.think(m, dt)
            self.move(m, dt)
            keep.append(m)
        self.mobs = keep

    def think(self, m, dt):
        m.hurt = max(0.0, m.hurt - dt * 3)
        m.timer -= dt
        if m.panic > 0:
            m.panic -= dt
            m.walking = True
            if m.timer <= 0:
                m.target_yaw = random.uniform(0, 2 * math.pi)
                m.timer = random.uniform(0.4, 1.0)
        elif m.timer <= 0:
            if m.walking or random.random() < 0.4:
                m.walking = False
                m.timer = random.uniform(2.0, 6.0)
            else:
                m.walking = True
                m.target_yaw = m.yaw + random.uniform(-2.0, 2.0)
                m.timer = random.uniform(1.5, 4.0)
            if random.random() < 0.3:
                m.head_yaw = random.uniform(-0.6, 0.6)
        # turn toward the target heading
        diff = (m.target_yaw - m.yaw + math.pi) % (2 * math.pi) - math.pi
        m.yaw += max(-4 * dt, min(4 * dt, diff))

    def move(self, m, dt):
        speed = m.speed * (2.2 if m.panic > 0 else 1.0) if m.walking else 0.0
        fwd = m.forward()
        want = fwd * speed
        k = 1 - math.exp(-10 * dt)
        m.vel.x += (want.x - m.vel.x) * k
        m.vel.z += (want.z - m.vel.z) * k

        in_water = self.world.get_block_at(math.floor(m.pos.x), math.floor(m.pos.y + 0.3),
                                           math.floor(m.pos.z)) == WATER
        if in_water:
            m.vel.y = min(m.vel.y + 14 * dt, 1.6)
        else:
            m.vel.y = max(m.vel.y - 28 * dt, -30)

        nx = m.pos.x + m.vel.x * dt
        if self.blocked(m, nx, m.pos.z):
            if m.on_ground and not self.blocked_above(m):
                m.vel.y = 7.2               # hop up a block
            else:
                m.target_yaw += math.pi * random.uniform(0.5, 1.5)
            m.vel.x = 0.0
        else:
            m.pos.x = nx
        nz = m.pos.z + m.vel.z * dt
        if self.blocked(m, m.pos.x, nz):
            if m.on_ground and not self.blocked_above(m):
                m.vel.y = 7.2
            else:
                m.target_yaw += math.pi * random.uniform(0.5, 1.5)
            m.vel.z = 0.0
        else:
            m.pos.z = nz

        ny = m.pos.y + m.vel.y * dt
        if m.vel.y <= 0:
            h = m.half * 0.9
            floor_y = math.floor(ny)
            landed = any(self.solid(cx, floor_y, cz)
                         for cx in (m.pos.x - h, m.pos.x + h)
                         for cz in (m.pos.z - h, m.pos.z + h))
            if landed:
                m.pos.y = floor_y + 1.0
                m.vel.y = 0.0
                m.on_ground = True
            else:
                m.pos.y = ny
                m.on_ground = False
        else:
            if self.solid(m.pos.x, ny + m.height, m.pos.z):
                m.vel.y = 0.0
            else:
                m.pos.y = ny
            m.on_ground = False
        if m.pos.y < -40:
            m.dead = 0.01

        moved = math.hypot(m.vel.x, m.vel.z)
        m.limb_amount += (min(1.0, moved / 1.5) - m.limb_amount) * min(1.0, 8 * dt)
        m.limb += moved * dt * 6.0
        m.flap = (m.flap + dt * 20) if not m.on_ground else 0.0

    def blocked_above(self, m):
        saved = m.pos.y
        m.pos.y += 1.05
        hit = self.blocked(m, m.pos.x + m.vel.x * 0.05, m.pos.z + m.vel.z * 0.05)
        m.pos.y = saved
        return hit

    # ------------------------------------------------------------------
    # Combat
    # ------------------------------------------------------------------
    def raycast(self, origin, direction, reach):
        """(mob, distance) of the nearest living mob along the ray, or None."""
        best = None
        for m in self.mobs:
            if m.dead:
                continue
            s = MODELS[m.kind]['scale']
            lo = glm.vec3(m.pos.x - m.half * s, m.pos.y, m.pos.z - m.half * s)
            hi = glm.vec3(m.pos.x + m.half * s, m.pos.y + m.height * s, m.pos.z + m.half * s)
            tmin, tmax = 0.0, reach
            ok = True
            for a in range(3):
                d = direction[a]
                if abs(d) < 1e-9:
                    if origin[a] < lo[a] or origin[a] > hi[a]:
                        ok = False
                        break
                    continue
                t1, t2 = (lo[a] - origin[a]) / d, (hi[a] - origin[a]) / d
                if t1 > t2:
                    t1, t2 = t2, t1
                tmin, tmax = max(tmin, t1), min(tmax, t2)
                if tmin > tmax:
                    ok = False
                    break
            if ok and (best is None or tmin < best[1]):
                best = (m, tmin)
        return best

    def hit(self, m, direction, damage=2):
        m.health -= damage
        m.hurt = 1.0
        m.panic = 4.0
        m.timer = 0.0
        push = glm.normalize(glm.vec3(direction.x, 0.0, direction.z) + 1e-6) * 5.0
        m.vel.x, m.vel.z = push.x, push.z
        m.vel.y = 5.5
        m.on_ground = False
        if m.health <= 0:
            m.dead = 0.01

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------
    def render(self, view, proj, cam_pos, fog_start, fog_end, t):
        if not self.enabled or not self.mobs:
            return
        p = self.prog
        p['m_proj'].write(proj.to_bytes())
        p['m_view'].write(view.to_bytes())
        p['cam_pos'].write(cam_pos)
        p['fog_range'].write(glm.vec2(fog_start, fog_end))
        r = self.renderer
        for name, value in (('u_daylight', r.daylight), ('u_time', t)):
            if name in p:
                p[name] = float(value)
        if 'u_sun_dir' in p:
            p['u_sun_dir'].write(r.sun_dir)
        if 'sky_horizon' in p:
            p['sky_horizon'].write(r.bg_color)
            p['sky_zenith'].write(r.sky_zenith)
        p['u_tex'] = 4
        self.ctx.disable(mgl.CULL_FACE)
        for m in self.mobs:
            tex = self.texture(m.texture)
            if tex is None:
                continue
            tex.use(4)
            p['u_hurt'] = float(max(m.hurt, 1.0 if m.dead else 0.0))
            base = glm.translate(m.pos) * glm.rotate(m.yaw, glm.vec3(0, 1, 0))
            if m.dead:
                base = base * glm.rotate(min(1.0, m.dead * 3) * HALF_PI, glm.vec3(0, 0, 1))
            s = MODELS[m.kind]['scale']
            if s != 1.0:
                base = base * glm.scale(glm.vec3(s))
            base = base * MODEL_TO_WORLD
            swing = math.cos(m.limb * 0.6662) * 1.4 * m.limb_amount
            for name, pivot, xrot, vao, _ in self.parts[m.kind]:
                rx, ry, rz = xrot, 0.0, 0.0
                if name.startswith('leg'):
                    i = int(name[3:])
                    rx += swing if i in (0, 3) else -swing
                elif name == 'head':
                    ry = m.head_yaw
                elif name.startswith('wing'):
                    rz = (math.sin(m.flap) + 1.0) * (1 if name == 'wing0' else -1) if m.flap else 0.0
                elif name.startswith('tail'):
                    rx += math.sin(m.limb * 0.5) * 0.15 * m.limb_amount
                mat = base * glm.translate(pivot)
                if ry:
                    mat = mat * glm.rotate(ry, glm.vec3(0, 1, 0))
                if rz:
                    mat = mat * glm.rotate(rz, glm.vec3(0, 0, 1))
                if rx:
                    mat = mat * glm.rotate(rx, glm.vec3(1, 0, 0))
                p['m_model'].write(mat.to_bytes())
                vao.render(mgl.TRIANGLES)
        self.ctx.enable(mgl.CULL_FACE)
