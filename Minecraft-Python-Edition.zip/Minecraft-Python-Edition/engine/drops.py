"""Dropped items: what a broken block or a killed animal leaves on the ground.

As in the real game a drop pops out with a little hop, falls and slides to a
stop, bobs and turns slowly, merges with drops of the same thing next to it,
and flies to the player once they are close enough — after a short delay, so
a block you have just broken does not vanish into your pocket mid-air. A drop
nobody picks up despawns after five minutes.

Blocks are drawn as little cubes with their own face textures; items and
non-cube blocks (torches, flowers) as a flat sprite that turns.
"""

import math
import random

import glm
import moderngl as mgl
import numpy as np
import pygame as pg

from world.blocks import COLLIDES, FACE_LAYER, ICON_LAYER, SHAPE_NAME
from world.modern_chunk import WATER
from game import items

LIFETIME = 300.0
PICKUP_DELAY = 0.6
MAGNET = 2.4          # blocks: starts flying to the player
GRAB = 0.9            # blocks: in the inventory
MERGE = 0.9


class Drop:
    __slots__ = ('id', 'count', 'pos', 'vel', 'age', 'spin', 'on_ground')

    def __init__(self, bid, count, pos, vel):
        self.id, self.count = int(bid), int(count)
        self.pos, self.vel = glm.vec3(pos), glm.vec3(vel)
        self.age = 0.0
        self.spin = random.uniform(0, 2 * math.pi)
        self.on_ground = False


def _cube_mesh():
    # x, y, z, u, v, face   (faces: top, bottom, +Z, -Z, +X, -X — FACE_LAYER's order)
    h = 0.5
    quads = (
        (0, ((-h, h, -h), (-h, h, h), (h, h, h), (h, h, -h))),
        (1, ((-h, -h, h), (-h, -h, -h), (h, -h, -h), (h, -h, h))),
        (2, ((-h, h, h), (-h, -h, h), (h, -h, h), (h, h, h))),
        (3, ((h, h, -h), (h, -h, -h), (-h, -h, -h), (-h, h, -h))),
        (4, ((h, h, h), (h, -h, h), (h, -h, -h), (h, h, -h))),
        (5, ((-h, h, -h), (-h, -h, -h), (-h, -h, h), (-h, h, h))),
    )
    uvs = ((0, 0), (0, 1), (1, 1), (1, 0))
    out = []
    for face, corners in quads:
        for i in (0, 1, 2, 0, 2, 3):
            out += [*corners[i], *uvs[i], face]
    return np.array(out, dtype='f4')


def _sprite_mesh():
    h = 0.5
    corners = ((-h, h, 0), (-h, -h, 0), (h, -h, 0), (h, h, 0))
    uvs = ((0, 0), (0, 1), (1, 1), (1, 0))
    out = []
    for i in (0, 1, 2, 0, 2, 3):
        out += [*corners[i], *uvs[i], 0]
    return np.array(out, dtype='f4')


class Drops:
    def __init__(self, renderer, world):
        self.renderer = renderer
        self.world = world
        self.ctx = renderer.ctx
        sm = renderer.shader_manager
        self.prog = sm.get_program('drop') or sm.load_shader(
            'drop', 'shaders/drop.vert', 'shaders/drop.frag')
        self.drops = []
        self.textures = {}
        self.merge_clock = 0.0
        self.vaos = {}
        if self.prog is not None:
            for name, data in (('cube', _cube_mesh()), ('sprite', _sprite_mesh())):
                vbo = self.ctx.buffer(data.tobytes())
                vao = self.ctx.vertex_array(self.prog, [(vbo, '3f 2f 1f', 'in_position', 'in_uv', 'in_face')])
                self.vaos[name] = (vao, vbo)

    def release(self):
        for vao, vbo in self.vaos.values():
            vao.release()
            vbo.release()
        for t in self.textures.values():
            if t:
                t.release()
        self.vaos, self.textures = {}, {}

    # ------------------------------------------------------------------
    def spawn(self, bid, count, x, y, z, burst=True):
        """Drop *count* of *bid* at (x, y, z) with the little hop of a broken block."""
        if not bid or count <= 0:
            return
        limit = items.stack_limit(bid)
        while count > 0:
            n = min(count, limit)
            count -= n
            vel = (glm.vec3(random.uniform(-1.2, 1.2), random.uniform(3.0, 4.5),
                            random.uniform(-1.2, 1.2)) if burst else glm.vec3(0.0))
            self.drops.append(Drop(bid, n, (x, y, z), vel))

    def solid(self, x, y, z):
        return bool(COLLIDES[self.world.get_block_at(math.floor(x), math.floor(y), math.floor(z))])

    def update(self, dt, player, inventory, can_pick):
        """Move every drop; give the player what reaches them. Returns True if
        anything was picked up (the hotbar needs a refresh)."""
        picked = False
        body = glm.vec3(player.x, player.y - 0.9, player.z)
        keep = []
        for d in self.drops:
            d.age += dt
            if d.age > LIFETIME:
                continue
            to = body - d.pos
            dist = glm.length(to)
            if can_pick and d.age > PICKUP_DELAY and dist < MAGNET:
                if dist < GRAB:
                    left = inventory.add(d.id, d.count)
                    if left < d.count:
                        picked = True
                    if left == 0:
                        continue
                    d.count = left
                else:
                    d.vel = glm.normalize(to) * 9.0
                    d.pos += d.vel * dt
                    keep.append(d)
                    continue
            self._physics(d, dt)
            keep.append(d)
        self.drops = keep

        self.merge_clock -= dt
        if self.merge_clock <= 0:
            self.merge_clock = 0.5
            self._merge()
        return picked

    def _physics(self, d, dt):
        if self.world.get_chunk(math.floor(d.pos.x) // 16, math.floor(d.pos.z) // 16) is None:
            return
        in_water = self.world.get_block_at(math.floor(d.pos.x), math.floor(d.pos.y),
                                           math.floor(d.pos.z)) == WATER
        if in_water:
            d.vel.y = min(d.vel.y + 10 * dt, 1.0)
        else:
            d.vel.y = max(d.vel.y - 22 * dt, -20.0)
        if self.solid(d.pos.x, d.pos.y + 0.05, d.pos.z):
            d.pos.y = math.floor(d.pos.y + 0.05) + 1.0      # spawned inside: pop up
            d.vel.y = 0.0
        nx = d.pos.x + d.vel.x * dt
        if self.solid(nx, d.pos.y + 0.1, d.pos.z):
            d.vel.x = 0.0
        else:
            d.pos.x = nx
        nz = d.pos.z + d.vel.z * dt
        if self.solid(d.pos.x, d.pos.y + 0.1, nz):
            d.vel.z = 0.0
        else:
            d.pos.z = nz
        ny = d.pos.y + d.vel.y * dt
        if d.vel.y <= 0 and self.solid(d.pos.x, ny, d.pos.z):
            d.pos.y = math.floor(ny) + 1.0
            d.vel.y = 0.0
            d.on_ground = True
        else:
            d.pos.y = ny
            d.on_ground = False
        if d.on_ground:
            k = math.exp(-8 * dt)
            d.vel.x *= k
            d.vel.z *= k

    def _merge(self):
        ds = self.drops
        for i, a in enumerate(ds):
            if a.count <= 0:
                continue
            limit = items.stack_limit(a.id)
            for b in ds[i + 1:]:
                if b.count <= 0 or b.id != a.id or a.count >= limit:
                    continue
                if glm.length(a.pos - b.pos) < MERGE:
                    move = min(b.count, limit - a.count)
                    a.count += move
                    b.count -= move
                    a.age = min(a.age, b.age)
        self.drops = [d for d in ds if d.count > 0]

    # ------------------------------------------------------------------
    def texture(self, bid):
        tex = self.textures.get(bid)
        if tex is None and bid not in self.textures:
            it = items.get(bid)
            try:
                surf = pg.image.load(it.texture)
                tex = self.ctx.texture(surf.get_size(), 4, pg.image.tostring(surf, 'RGBA'))
                tex.filter = (mgl.NEAREST, mgl.NEAREST)
            except (pg.error, FileNotFoundError, AttributeError):
                tex = None
            self.textures[bid] = tex
        return tex

    def render(self, view, proj, cam_pos, fog_start, fog_end, t):
        if not self.drops or self.prog is None:
            return
        p = self.prog
        r = self.renderer
        p['m_proj'].write(proj.to_bytes())
        p['m_view'].write(view.to_bytes())
        p['cam_pos'].write(cam_pos)
        p['fog_range'].write(glm.vec2(fog_start, fog_end))
        for name, value in (('u_daylight', r.daylight), ('u_time', t)):
            if name in p:
                p[name] = float(value)
        if 'u_sun_dir' in p:
            p['u_sun_dir'].write(r.sun_dir)
        if 'sky_horizon' in p:
            p['sky_horizon'].write(r.bg_color)
            p['sky_zenith'].write(r.sky_zenith)
        if 'u_blocks' in p:
            p['u_blocks'] = 0
        if 'u_tex' in p:
            p['u_tex'] = 4
        if r.block_texture:
            r.block_texture.use(0)
        self.ctx.disable(mgl.CULL_FACE)
        for d in self.drops:
            bob = math.sin(d.age * 2.2 + d.spin) * 0.07 + 0.2
            base = glm.translate(glm.vec3(d.pos.x, d.pos.y + bob, d.pos.z)) * \
                glm.rotate(d.age * 1.6 + d.spin, glm.vec3(0, 1, 0))
            copies = 1 if d.count == 1 else 2 if d.count < 17 else 3
            if items.is_item(d.id):
                tex = self.texture(d.id)
                if tex is None:
                    continue
                tex.use(4)
                p['u_mode'] = 1
                vao, scale = self.vaos['sprite'][0], 0.5
            elif d.id in SHAPE_NAME:
                p['u_mode'] = 2
                p['u_layers'].write(np.array([ICON_LAYER.get(d.id, 0)] * 6, dtype='f4').tobytes())
                vao, scale = self.vaos['sprite'][0], 0.5
            else:
                p['u_mode'] = 0
                layers = np.array([FACE_LAYER[d.id, f] for f in range(6)], dtype='f4')
                p['u_layers'].write(layers.tobytes())
                vao, scale = self.vaos['cube'][0], 0.25
            for c in range(copies):
                off = glm.vec3(0.06 * c, 0.05 * c, -0.05 * c)
                m = base * glm.translate(off) * glm.scale(glm.vec3(scale))
                p['m_model'].write(m.to_bytes())
                vao.render(mgl.TRIANGLES)
        self.ctx.enable(mgl.CULL_FACE)
