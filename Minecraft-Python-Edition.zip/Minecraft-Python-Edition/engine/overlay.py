"""A full-screen 2D layer drawn with pygame and shown with one textured quad.

Menus, hearts, item counts and the inventory are ordinary pygame drawing onto
an RGBA Surface. The Surface is uploaded only when something on it changed —
`mark()` is how the caller says so — so an unchanging HUD costs one draw call a
frame and no upload at all.
"""

import moderngl as mgl
import numpy as np
import pygame as pg

_VERT = """
#version 330 core
in vec2 in_pos;
out vec2 v_uv;
void main() {
    v_uv = in_pos * 0.5 + 0.5;
    gl_Position = vec4(in_pos, 0.0, 1.0);
}
"""

_FRAG = """
#version 330 core
in vec2 v_uv;
uniform sampler2D u_tex;
uniform vec4 u_color;
uniform int u_mode;     // 0 = texture, 1 = flat colour
out vec4 fragColor;
void main() {
    fragColor = u_mode == 0 ? texture(u_tex, vec2(v_uv.x, 1.0 - v_uv.y)) : u_color;
}
"""


class Overlay:
    def __init__(self, ctx, width, height):
        self.ctx = ctx
        self.prog = ctx.program(vertex_shader=_VERT, fragment_shader=_FRAG)
        quad = np.array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1], dtype='f4')
        self.vbo = ctx.buffer(quad.tobytes())
        self.vao = ctx.vertex_array(self.prog, [(self.vbo, '2f', 'in_pos')])
        self.texture = None
        self.surface = None
        self.key = object()      # what the surface currently shows
        self.empty = True
        self.resize(width, height)

    def resize(self, width, height):
        self.width, self.height = width, height
        self.surface = pg.Surface((width, height), pg.SRCALPHA)
        if self.texture:
            self.texture.release()
        self.texture = self.ctx.texture((width, height), 4)
        self.texture.filter = (mgl.NEAREST, mgl.NEAREST)
        self.key = object()

    def needs(self, key):
        """True (and remembers *key*) when the caller must redraw the surface.
        Callers build a key out of everything they draw; equal key, no work."""
        if key == self.key:
            return False
        self.key = key
        self.surface.fill((0, 0, 0, 0))
        self._dirty = True
        return True

    def _gl_state(self):
        ctx = self.ctx
        ctx.disable(mgl.DEPTH_TEST)
        ctx.disable(mgl.CULL_FACE)
        ctx.enable(mgl.BLEND)
        ctx.blend_func = mgl.SRC_ALPHA, mgl.ONE_MINUS_SRC_ALPHA

    def _restore(self):
        self.ctx.enable(mgl.DEPTH_TEST)
        self.ctx.enable(mgl.CULL_FACE)

    def draw(self):
        if getattr(self, '_dirty', False):
            self.texture.write(pg.image.tostring(self.surface, 'RGBA'))
            self._dirty = False
        self._gl_state()
        self.texture.use(5)
        self.prog['u_tex'] = 5
        self.prog['u_mode'] = 0
        self.vao.render(mgl.TRIANGLES)
        self._restore()

    def tint(self, rgba):
        """Wash the whole frame with one colour — underwater, damage, menus."""
        self._gl_state()
        self.prog['u_mode'] = 1
        self.prog['u_color'] = tuple(c / 255.0 for c in rgba)
        self.vao.render(mgl.TRIANGLES)
        self._restore()

    def release(self):
        for obj in (self.texture, self.vao, self.vbo, self.prog):
            obj.release()
