"""The game's font: Galmuri11, a Korean pixel font (SIL OFL, assets/font).

Pixel fonts only look right at whole multiples of their design size and with
antialiasing off, so every size asked for is snapped to a multiple of 12 px and
`AA` is False — which is what gives the menus the blocky Minecraft look.
If the bundled font is missing, a Korean system font is used instead.
"""

import os

import pygame as pg

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PIXEL = os.path.join(_HERE, 'assets', 'font', 'Galmuri11.ttf')
PIXEL_BOLD = os.path.join(_HERE, 'assets', 'font', 'Galmuri11-Bold.ttf')
DESIGN = 12

KOREAN_FONTS = ('malgungothic', 'applesdgothicneo', 'nanumgothic', 'notosanscjkkr',
                'notosanskr', 'notosanscjk', 'gulim')

AA = not os.path.exists(PIXEL)       # antialias only for a fallback system font
_cache = {}


def _fallback():
    for name in KOREAN_FONTS:
        path = pg.font.match_font(name)
        if path:
            return path
    return None


def snap(size):
    """Nearest whole multiple of the pixel font's design size."""
    return max(DESIGN, int(round(size / DESIGN)) * DESIGN)


def font(size, bold=False):
    """A cached font at roughly *size* pixels."""
    if not pg.font.get_init():
        pg.font.init()
    if not AA:
        size = snap(size)
    key = (size, bold)
    f = _cache.get(key)
    if f is None:
        if not AA:
            f = pg.font.Font(PIXEL_BOLD if bold and os.path.exists(PIXEL_BOLD) else PIXEL, size)
        else:
            path = _fallback()
            f = pg.font.Font(path, size) if path else pg.font.Font(None, size)
        _cache[key] = f
    return f


def render(f, text, color):
    return f.render(text, AA, color)
