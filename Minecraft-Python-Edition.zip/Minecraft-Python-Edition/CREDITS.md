# CREDITS

Ocstrom Manubo1이 아래 오픈소스를 가져와 만들었습니다.

- [StanislavPetrovV/Minecraft](https://github.com/StanislavPetrovV/Minecraft) — MIT — 참고 (가져왔던 extra/ 모듈은 연결되지 않아 Python Edition에서 제거)
- [iEmreM/Minecraft-Clone](https://github.com/iEmreM/Minecraft-Clone) — MIT — 베이스
- [obiwac/python-minecraft-clone](https://github.com/obiwac/python-minecraft-clone) — MIT — 참고

## Minecraft: Python Edition

타이틀·월드 저장·서바이벌·낮밤·메뉴 등은 Claude가 이 베이스 위에 덧붙였습니다.
Minecraft는 Mojang Studios의 상표이며, 이 프로젝트는 비공식 팬 메이드입니다.

## 1.1 에셋

- 폰트: [Galmuri](https://github.com/quiple/galmuri) (갈무리11) — SIL Open Font License 1.1, `assets/font/OFL.md`
- 로고, 동물·해·달·GUI 텍스처(`assets/gui`, `assets/entity`, `assets/sky`): 프로젝트 주인이 제공한 파일.
  동물·해·달·GUI 텍스처는 Mojang의 Minecraft 원본 리소스라 개인 용도로만 쓰고, 배포할 때는 빼야 합니다.

## 1.3 에셋

- 아이템 그림(`assets/items`): 프로젝트 주인이 준 16×16 그림(Mc-texchy 폴더). 원본은 Mojang의 Minecraft 아이템 텍스처라 개인 용도로만.
  구리·네더라이트 도구, 구리·금·네더라이트 주괴, 네더라이트 파편, 익힌 돼지고기, 막대기는 이 그림들의 픽셀을 그대로 쓰고
  색만 바꿔 만든 것(픽셀 재활용).
