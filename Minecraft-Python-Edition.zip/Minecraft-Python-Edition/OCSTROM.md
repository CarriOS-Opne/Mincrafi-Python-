# voxel-game → Minecraft: Python Edition

요청: 파이썬으로 마인크래프트 만들어줘 → 다듬어서 "마인크래프트 파이썬 에디션"으로

베이스: iEmreM/Minecraft-Clone (MIT) — 원래 설명은 README.base.md, 새 설명은 README.md

## 빌드
```
python -m compileall -q .
```

## 실행
```
python main.py      (Windows: 실행.bat)
```

## Python Edition에서 바뀐 것
- 타이틀/월드 선택/월드 만들기/일시정지/설정/사망 화면 (한국어, game/ui.py)
- 월드 저장·불러오기 + 시드 (game/save.py, world/terrain_generator.py set_seed)
- 서바이벌: 체력·낙하·익사·채굴 시간·드롭·인벤토리 (game/survival.py)
- 낮/밤, 별, 해·달, 노을 (shaders/sky_common.glsl)
- 수영 (engine/camera.py)
- 명령어 /gamemode /time /give /seed /kill /spawnpoint
- 고친 버그: 스폰 청크가 미리 생성되지 않던 문제, 나무 속 스폰, MSAA 없는 PC에서 창이 안 뜨던 문제,
  빈 핫바에서 크래시, 터키어 UI
- extra/ (연결 안 된 외부 모듈) 제거
