@echo off
cd /d "%~dp0"

set PY=
if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set PY="%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY (
  where py >nul 2>nul && set PY=py
)
if not defined PY (
  where python >nul 2>nul && set PY=python
)
if not defined PY (
  echo Python not found. Install it from https://www.python.org
  pause
  exit /b 1
)

%PY% -c "import moderngl, pygame, numpy, glm, numba" >nul 2>nul
if errorlevel 1 %PY% -m pip install -r requirements.txt

%PY% main.py
pause
