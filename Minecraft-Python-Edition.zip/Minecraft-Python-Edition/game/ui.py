"""Menus, drawn with pygame onto the overlay (engine/overlay.py).

Everything is laid out in *GUI pixels* and multiplied by a GUI scale, the way
the real game does it, so buttons are 200x20, a slot is 18x18 and the pixel
font lands on whole pixels. Container screens (inventory, crafting table,
furnace) draw the game's own GUI textures from assets/gui.
"""

import datetime
import math
import os
import random
import time

import pygame as pg

from engine import fonts
from world.blocks import BLOCK_NAMES, ICON_LAYER, FACE_LAYER, SHAPE_NAME
from game import crafting, items

WHITE = (255, 255, 255)
GREY = (160, 160, 160)
LABEL = (64, 64, 64)
YELLOW = (255, 255, 85)
HOVER_TEXT = (255, 255, 160)

VERSION = 'Minecraft: Python Edition 1.1'
ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets')

SPLASHES = (
    '파이썬으로 만들었어요!', '100% 순수 파이썬!*', 'numba 덕분에 빠름!',
    '677가지 블록!', '무한한 세계!', '26가지 바이옴!', 'pip install fun',
    '들여쓰기는 4칸!', '마을도 있어요!', 'import minecraft', '뱀이 아니라 파이썬!',
    'ModernGL로 그렸어요!', '그림자 추가!', '돼지가 꿀꿀!', '고양이 있어요!',
)


def gui_scale(w, h):
    """The real game's "auto" GUI scale: the largest that still fits 320x240."""
    return max(1, min(4, w // 320, h // 240))


def font_px(scale):
    return 12 if scale <= 2 else 24


def small_px(scale):
    """Labels and stack counts inside a container, which has 8 GUI px of room."""
    return 12 if scale <= 3 else 24


# ---------------------------------------------------------------------------
# Images
# ---------------------------------------------------------------------------

_images = {}


def image(rel):
    img = _images.get(rel)
    if img is None:
        try:
            img = pg.image.load(os.path.join(ASSETS, rel))
        except (pg.error, FileNotFoundError):
            img = None
        _images[rel] = img
    return img


def scaled(rel, size):
    key = (rel, size)
    img = _images.get(key)
    if img is None:
        base = image(rel)
        if base is None:
            return None
        img = _images[key] = pg.transform.scale(base, size)
    return img


# ---------------------------------------------------------------------------
# Drawing helpers
# ---------------------------------------------------------------------------

def text(surf, s, size, color=WHITE, center=None, topleft=None, midleft=None,
         topright=None, shadow=True, bold=False, alpha=255):
    f = fonts.font(size, bold)
    img = fonts.render(f, s, color)
    rect = img.get_rect()
    if center is not None:
        rect.center = center
    elif topleft is not None:
        rect.topleft = topleft
    elif midleft is not None:
        rect.midleft = midleft
    elif topright is not None:
        rect.topright = topright
    if shadow:
        sh = fonts.render(f, s, tuple(c // 4 for c in color))
        if alpha < 255:
            sh.set_alpha(alpha)
        off = max(1, f.get_height() // 10)
        surf.blit(sh, rect.move(off, off))
    if alpha < 255:
        img.set_alpha(alpha)
    surf.blit(img, rect)
    return rect


def panel(surf, rect, alpha=150):
    s = pg.Surface(rect.size, pg.SRCALPHA)
    s.fill((0, 0, 0, alpha))
    surf.blit(s, rect.topleft)


def dim(surf, alpha=110):
    """The in-game menu backdrop: a dark gradient, lighter at the top."""
    w, h = surf.get_size()
    g = _images.get(('dim', w, h, alpha))
    if g is None:
        g = pg.Surface((w, h), pg.SRCALPHA)
        for y in range(0, h, 2):
            a = int(alpha * (0.75 + 0.25 * y / h))
            g.fill((16, 16, 16, a), (0, y, w, 2))
        _images[('dim', w, h, alpha)] = g
    surf.blit(g, (0, 0))


def dirt(surf, icons, rect=None, shade=64):
    """The options-screen background: dirt, darkened."""
    rect = rect or surf.get_rect()
    s = gui_scale(*surf.get_size()) * 16 * 2
    tile = icons.get(2, s, flat=True)
    if tile is None:
        surf.fill((40, 30, 22, 255), rect)
        return
    t = tile.copy()
    t.fill((shade, shade, shade), special_flags=pg.BLEND_MULT)
    clip = surf.get_clip()
    surf.set_clip(rect)
    for y in range(rect.top - rect.top % s, rect.bottom, s):
        for x in range(0, rect.right, s):
            surf.blit(t, (x, y))
    surf.set_clip(clip)


class Icons:
    """Block icons cut out of texture.png for pygame-drawn screens: a little
    isometric cube for a cube block, the flat sprite for a torch or a flower —
    the way the real game draws items in slots."""

    def __init__(self, path='texture.png'):
        try:
            self.atlas = pg.image.load(path)
        except pg.error:
            self.atlas = None
        self.cache = {}

    def tile(self, layer):
        return self.atlas.subsurface((0, int(layer) * 16, 16, 16)).copy()

    def get(self, block, size, flat=False):
        key = (block, size, flat)
        img = self.cache.get(key)
        if img is None and items.is_item(block):
            it = items.get(block)
            try:
                img = pg.transform.scale(pg.image.load(it.texture), (size, size))
            except (pg.error, FileNotFoundError, AttributeError):
                return None
            self.cache[key] = img
            return img
        if img is None:
            layer = ICON_LAYER.get(block)
            if self.atlas is None or layer is None:
                return None
            if flat or block in SHAPE_NAME:
                img = pg.transform.scale(self.tile(layer), (size, size))
            else:
                img = self.cube(block, size)
            self.cache[key] = img
        return img

    def cube(self, block, size):
        S = size
        h = S // 2
        q = S // 4
        out = pg.Surface((S, S), pg.SRCALPHA)
        top = self.tile(FACE_LAYER[block, 0])
        front = self.tile(FACE_LAYER[block, 2])
        right = self.tile(FACE_LAYER[block, 4])

        # top: the tile turned 45 degrees and squashed to half height
        t = pg.transform.rotate(pg.transform.scale(top, (64, 64)), 45)
        out.blit(pg.transform.scale(t, (S, h + 1)), (0, 0))

        # the two sides: columns of the tile, each slid down (left) or up (right)
        for face, shade, left in ((front, 205, True), (right, 150, False)):
            f = pg.transform.scale(face, (h, h))
            f.fill((shade, shade, shade), special_flags=pg.BLEND_MULT)
            for c in range(h):
                col = f.subsurface((c, 0, 1, f.get_height()))
                if left:
                    out.blit(col, (c, q + c // 2))
                else:
                    out.blit(col, (h + c, q + (h - c) // 2))
        return out


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------

def draw_button(surf, r, label, hover, enabled, s):
    """A Minecraft button: black outline, bevelled grey face, shadowed text."""
    if not enabled:
        face, light, dark = (44, 44, 44), (60, 60, 60), (30, 30, 30)
    elif hover:
        face, light, dark = (126, 136, 191), (168, 176, 222), (86, 94, 140)
    else:
        face, light, dark = (111, 111, 111), (168, 168, 168), (76, 76, 76)
    surf.fill((0, 0, 0), r)
    inner = r.inflate(-2 * s, -2 * s)
    surf.fill(face, inner)
    surf.fill(light, (inner.x, inner.y, inner.w, s))
    surf.fill(light, (inner.x, inner.y, s, inner.h))
    surf.fill(dark, (inner.x, inner.bottom - 2 * s, inner.w, 2 * s))
    surf.fill(dark, (inner.right - s, inner.y, s, inner.h))
    if hover and enabled:
        pg.draw.rect(surf, WHITE, r, s)
    color = (HOVER_TEXT if hover else (224, 224, 224)) if enabled else (160, 160, 160)
    text(surf, label, font_px(s), color, center=(r.centerx, r.centery - s // 2))


class Widget:
    rect = pg.Rect(0, 0, 0, 0)
    scale = 2


class Button(Widget):
    def __init__(self, label, action, enabled=True):
        self.label = label
        self.action = action
        self.enabled = enabled
        self.rect = pg.Rect(0, 0, 0, 0)

    def caption(self):
        return self.label() if callable(self.label) else self.label

    def draw(self, surf, mouse):
        draw_button(surf, self.rect, self.caption(), self.rect.collidepoint(mouse),
                    self.enabled, self.scale)

    def event(self, e):
        if (e.type == pg.MOUSEBUTTONDOWN and e.button == 1 and self.enabled
                and self.rect.collidepoint(e.pos)):
            self.action()
            return True
        return False


class Slider(Widget):
    def __init__(self, label, lo, hi, get, set_, step=1):
        self.label, self.lo, self.hi = label, lo, hi
        self.get, self.set, self.step = get, set_, step
        self.rect = pg.Rect(0, 0, 0, 0)
        self.dragging = False

    def draw(self, surf, mouse):
        r, s = self.rect, self.scale
        draw_button(surf, r, '', False, False, s)
        frac = (self.get() - self.lo) / (self.hi - self.lo)
        kw = 8 * s
        knob = pg.Rect(r.x + int(frac * (r.w - kw)), r.y, kw, r.h)
        draw_button(surf, knob, '', r.collidepoint(mouse) or self.dragging, True, s)
        hover = r.collidepoint(mouse) or self.dragging
        text(surf, self.label(self.get()), font_px(s), HOVER_TEXT if hover else (224, 224, 224),
             center=(r.centerx, r.centery - s // 2))

    def _to_value(self, x):
        frac = min(max((x - self.rect.x) / max(1, self.rect.w), 0.0), 1.0)
        v = self.lo + frac * (self.hi - self.lo)
        v = round(v / self.step) * self.step
        return min(max(v, self.lo), self.hi)

    def event(self, e):
        if e.type == pg.MOUSEBUTTONDOWN and e.button == 1 and self.rect.collidepoint(e.pos):
            self.dragging = True
            self.set(self._to_value(e.pos[0]))
            return True
        if e.type == pg.MOUSEMOTION and self.dragging:
            self.set(self._to_value(e.pos[0]))
            return True
        if e.type == pg.MOUSEBUTTONUP and e.button == 1 and self.dragging:
            self.dragging = False
            return True
        return False


class TextField(Widget):
    def __init__(self, value='', placeholder='', maxlen=32):
        self.value, self.placeholder, self.maxlen = value, placeholder, maxlen
        self.rect = pg.Rect(0, 0, 0, 0)
        self.focused = False

    def draw(self, surf, mouse):
        r, s = self.rect, self.scale
        surf.fill(WHITE if self.focused else (160, 160, 160), r)
        surf.fill((0, 0, 0), r.inflate(-2 * s, -2 * s))
        size = font_px(s)
        caret = self.focused and int(time.time() * 3) % 2 == 0
        if self.value or self.focused:
            text(surf, self.value + ('_' if caret else ''), size, (224, 224, 224),
                 midleft=(r.x + 4 * s, r.centery))
        else:
            text(surf, self.placeholder, size, (112, 112, 112),
                 midleft=(r.x + 4 * s, r.centery), shadow=False)

    def event(self, e):
        if e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
            self.focused = self.rect.collidepoint(e.pos)
            return self.focused
        if not self.focused:
            return False
        if e.type == pg.TEXTINPUT:
            self.value = (self.value + e.text)[:self.maxlen]
            return True
        if e.type == pg.KEYDOWN and e.key == pg.K_BACKSPACE:
            self.value = self.value[:-1]
            return True
        return False


# ---------------------------------------------------------------------------
# Screens
# ---------------------------------------------------------------------------

class Screen:
    """A menu. `pauses` stops the world behind it."""
    pauses = True

    def __init__(self, app):
        self.app = app
        self.widgets = []
        self.s = 2

    def layout(self, w, h):
        self.s = gui_scale(w, h)
        for wd in self.widgets:
            wd.scale = self.s
        self.place(w, h)

    def place(self, w, h):
        pass

    def button(self, wd, cx, y, gw=200, gh=20):
        """Put a widget at GUI-pixel width *gw*, centred on *cx*, top at *y*."""
        s = self.s
        wd.rect = pg.Rect(cx - gw * s // 2, y, gw * s, gh * s)

    def draw(self, surf, mouse):
        for wd in self.widgets:
            wd.draw(surf, mouse)

    def event(self, e):
        for wd in self.widgets:
            if wd.event(e):
                return True
        if e.type == pg.KEYDOWN and e.key == pg.K_ESCAPE:
            self.back()
            return True
        return False

    def back(self):
        self.app.close_screen()

    def title(self, surf, label, y):
        text(surf, label, font_px(self.s), WHITE, center=(surf.get_width() // 2, y))


class TitleScreen(Screen):
    def __init__(self, app):
        super().__init__(app)
        self.splash = random.choice(SPLASHES)
        self.single = Button('싱글플레이', lambda: app.open(WorldListScreen(app)))
        self.multi = Button('멀티플레이', None, enabled=False)
        self.options = Button('설정...', lambda: app.open(SettingsScreen(app, self)))
        self.quit = Button('게임 종료', app.quit)
        self.widgets = [self.single, self.multi, self.options, self.quit]

    def place(self, w, h):
        s = self.s
        y = h // 4 + 48 * s
        self.button(self.single, w // 2, y)
        self.button(self.multi, w // 2, y + 24 * s)
        self.button(self.options, w // 2 - 51 * s, y + 72 * s, 98)
        self.button(self.quit, w // 2 + 51 * s, y + 72 * s, 98)

    def back(self):
        pass

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        s = self.s
        g = _images.get(('fade', w, h))
        if g is None:
            g = pg.Surface((w, h), pg.SRCALPHA)
            for y in range(h):
                g.fill((0, 0, 0, int(70 + 50 * abs(y / h - 0.5) * 2)), (0, y, w, 1))
            _images[('fade', w, h)] = g
        surf.blit(g, (0, 0))

        logo = image('gui/logo.png')
        lw = min(int(w * 0.8), 300 * s)
        lh = int(lw * logo.get_height() / logo.get_width()) if logo else 0
        ly = 30 * s
        if logo:
            surf.blit(scaled('gui/logo.png', (lw, lh)), ((w - lw) // 2, ly))
        else:
            text(surf, 'MINECRAFT', 48, center=(w // 2, ly + 30))

        pulse = 1.0 + 0.08 * abs(math.sin(time.time() * 6.0))
        f = fonts.font(font_px(s))
        img = fonts.render(f, self.splash, YELLOW)
        sh = fonts.render(f, self.splash, (63, 63, 21))
        off = max(1, f.get_height() // 10)
        combo = pg.Surface((img.get_width() + off, img.get_height() + off), pg.SRCALPHA)
        combo.blit(sh, (off, off))
        combo.blit(img, (0, 0))
        combo = pg.transform.scale(combo, (int(combo.get_width() * pulse),
                                           int(combo.get_height() * pulse)))
        combo = pg.transform.rotate(combo, 20)
        sr = combo.get_rect(center=((w + lw) // 2 - 20 * s, ly + lh - 4 * s))
        sr.right = min(sr.right, w - 4)
        surf.blit(combo, sr)

        super().draw(surf, mouse)
        size = font_px(s if s < 3 else 2)
        text(surf, VERSION, size, WHITE, topleft=(2 * s, h - size - 2 * s))
        text(surf, 'Copyright Octobus · Mojang과 무관한 팬 메이드', size, WHITE,
             topright=(w - 2 * s, h - size - 2 * s))


class WorldListScreen(Screen):
    def __init__(self, app):
        super().__init__(app)
        from game import save
        self.worlds = save.list_worlds()
        self.selected = 0 if self.worlds else -1
        self.scroll = 0
        self.play = Button('선택한 월드 플레이', self._play, bool(self.worlds))
        self.create = Button('새로운 월드 만들기', lambda: app.open(CreateWorldScreen(app)))
        self.delete = Button('삭제', self._delete, bool(self.worlds))
        self.cancel = Button('취소', self.back)
        self.widgets = [self.play, self.create, self.delete, self.cancel]
        self.rows = []
        self._last_click = (0, -1)

    def back(self):
        self.app.open(TitleScreen(self.app))

    def place(self, w, h):
        s = self.s
        y1 = h - 52 * s
        self.button(self.play, w // 2 - 77 * s, y1, 150)
        self.button(self.create, w // 2 + 77 * s, y1, 150)
        self.button(self.delete, w // 2 - 77 * s, y1 + 24 * s, 150)
        self.button(self.cancel, w // 2 + 77 * s, y1 + 24 * s, 150)
        self.list_rect = pg.Rect(0, 32 * s, w, y1 - 36 * s - 32 * s + 4 * s)
        self.row_h = 36 * s
        self.row_w = 220 * s

    def _play(self):
        if 0 <= self.selected < len(self.worlds):
            self.app.start_world(self.worlds[self.selected]['folder'])

    def _delete(self):
        if 0 <= self.selected < len(self.worlds):
            world = self.worlds[self.selected]

            def really():
                from game import save
                save.delete_world(world['folder'])
                self.app.open(WorldListScreen(self.app))
            self.app.open(ConfirmScreen(
                self.app, f"'{world['name']}' 월드를 삭제할까요?",
                "'" + world['name'] + "' 월드는 영원히 사라집니다! (정말 오래!)", '삭제', really, self))

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        s = self.s
        lr = self.list_rect
        dirt(surf, self.app.icons, pg.Rect(0, 0, w, lr.top), 64)
        dirt(surf, self.app.icons, lr, 32)
        dirt(surf, self.app.icons, pg.Rect(0, lr.bottom, w, h - lr.bottom), 64)
        surf.fill((0, 0, 0), (0, lr.top, w, s))
        surf.fill((0, 0, 0), (0, lr.bottom - s, w, s))
        self.title(surf, '월드 선택', 16 * s)

        surf.set_clip(lr)
        self.rows = []
        y = lr.y + 4 * s - self.scroll
        x = (w - self.row_w) // 2
        fs = font_px(s)
        for i, wd in enumerate(self.worlds):
            r = pg.Rect(x, y, self.row_w, self.row_h - 4 * s)
            self.rows.append((r, i))
            if i == self.selected:
                surf.fill((128, 128, 128), r)
                surf.fill((0, 0, 0), r.inflate(-2 * s, -2 * s))
            icon = self.app.icons.get(1 if wd.get('mode') == 'survival' else 44, 32 * s - 4 * s)
            if icon:
                surf.blit(icon, (r.x + 2 * s, r.y + 2 * s))
            tx = r.x + 34 * s
            line = fs + 2
            text(surf, wd.get('name', wd['folder']), fs, WHITE, topleft=(tx, r.y + 2 * s))
            when = datetime.datetime.fromtimestamp(wd.get('last_played', 0)).strftime('%Y-%m-%d %H:%M')
            text(surf, f"{wd['folder']} ({when})", fs, (128, 128, 128),
                 topleft=(tx, r.y + 2 * s + line), shadow=False)
            mode = '서바이벌 모드' if wd.get('mode') == 'survival' else '크리에이티브 모드'
            text(surf, mode, fs, (128, 128, 128), topleft=(tx, r.y + 2 * s + 2 * line), shadow=False)
            y += self.row_h
        if not self.worlds:
            text(surf, '아직 월드가 없어요', fs, GREY, center=lr.center)
        surf.set_clip(None)
        super().draw(surf, mouse)

    def event(self, e):
        if e.type == pg.MOUSEWHEEL:
            total = len(self.worlds) * self.row_h + 8
            self.scroll = min(max(0, self.scroll - e.y * self.row_h // 2),
                              max(0, total - self.list_rect.h))
            return True
        if e.type == pg.MOUSEBUTTONDOWN and e.button == 1 and self.list_rect.collidepoint(e.pos):
            for r, i in self.rows:
                if r.collidepoint(e.pos):
                    now = time.time()
                    if self._last_click[1] == i and now - self._last_click[0] < 0.4:
                        self.selected = i
                        self._play()
                        return True
                    self._last_click = (now, i)
                    self.selected = i
                    return True
        if e.type == pg.KEYDOWN and e.key in (pg.K_RETURN, pg.K_KP_ENTER):
            self._play()
            return True
        return super().event(e)


class CreateWorldScreen(Screen):
    def __init__(self, app):
        super().__init__(app)
        self.mode = 'survival'
        self.name = TextField('새로운 월드', maxlen=32)
        self.seed = TextField('', '비워 두면 무작위', maxlen=32)
        self.mode_btn = Button(lambda: '게임 모드: ' + ('서바이벌' if self.mode == 'survival'
                                                       else '크리에이티브'), self._toggle)
        self.go = Button('새로운 월드 만들기', self._create)
        self.cancel = Button('취소', self.back)
        self.widgets = [self.name, self.seed, self.mode_btn, self.go, self.cancel]
        self.name.focused = True

    def _toggle(self):
        self.mode = 'creative' if self.mode == 'survival' else 'survival'

    def _create(self):
        self.app.create_world(self.name.value.strip() or '새로운 월드', self.seed.value, self.mode)

    def back(self):
        self.app.open(WorldListScreen(self.app))

    def place(self, w, h):
        s = self.s
        self.button(self.name, w // 2, 60 * s)
        self.button(self.seed, w // 2, 108 * s)
        self.button(self.mode_btn, w // 2, 140 * s)
        y = h - 28 * s
        self.button(self.go, w // 2 - 77 * s, y, 150)
        self.button(self.cancel, w // 2 + 77 * s, y, 150)

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        s = self.s
        dirt(surf, self.app.icons)
        fs = font_px(s)
        self.title(surf, '새로운 월드 만들기', 20 * s)
        text(surf, '월드 이름', fs, GREY, topleft=(self.name.rect.x, self.name.rect.y - fs - 3 * s))
        text(surf, '월드 생성기 시드', fs, GREY, topleft=(self.seed.rect.x, self.seed.rect.y - fs - 3 * s))
        desc = ('자원을 찾고, 제작하고, 살아남으세요.' if self.mode == 'survival'
                else '무한한 자원, 자유로운 비행, 즉시 파괴.')
        text(surf, desc, fs, GREY, center=(w // 2, self.mode_btn.rect.bottom + fs + 2 * s))
        super().draw(surf, mouse)

    def event(self, e):
        if e.type == pg.KEYDOWN and e.key in (pg.K_RETURN, pg.K_KP_ENTER):
            self._create()
            return True
        if e.type == pg.KEYDOWN and e.key == pg.K_TAB:
            self.name.focused, self.seed.focused = self.seed.focused, self.name.focused
            return True
        return super().event(e)


class ConfirmScreen(Screen):
    def __init__(self, app, title, message, yes_label, on_yes, parent):
        super().__init__(app)
        self.title_text, self.message, self.parent = title, message, parent
        self.yes = Button(yes_label, on_yes)
        self.no = Button('취소', self.back)
        self.widgets = [self.yes, self.no]

    def back(self):
        self.app.open(self.parent)

    def place(self, w, h):
        s = self.s
        self.button(self.yes, w // 2 - 77 * s, h // 6 + 96 * s, 150)
        self.button(self.no, w // 2 + 77 * s, h // 6 + 96 * s, 150)

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        dirt(surf, self.app.icons)
        self.title(surf, self.title_text, 70 * self.s)
        text(surf, self.message, font_px(self.s), WHITE, center=(w // 2, 90 * self.s))
        super().draw(surf, mouse)


class SettingsScreen(Screen):
    def __init__(self, app, parent):
        super().__init__(app)
        self.parent = parent
        o = app.options

        def setter(name):
            def set_(v):
                o[name] = v
                app.apply_options()
            return set_

        def toggle(label, name):
            return Button(lambda: f"{label}: {'켬' if o[name] else '끔'}",
                          lambda: setter(name)(not o[name]))

        self.widgets = [
            Slider(lambda v: f'렌더 거리: {int(v)} 청크', 2, 32,
                   lambda: o['render_distance'], setter('render_distance')),
            Slider(lambda v: f'시야: {int(v)}' + (' (보통)' if int(v) == 70 else
                                                ' (퀘이크 프로)' if int(v) >= 110 else ''),
                   30, 110, lambda: o['fov'], setter('fov')),
            Slider(lambda v: f'마우스 감도: {int(v * 100)}%', 0.2, 2.0,
                   lambda: o['sensitivity'], setter('sensitivity'), step=0.05),
            toggle('그림자', 'shadows'),
            toggle('동물', 'mobs'),
            toggle('낮/밤 주기', 'daylight_cycle'),
            toggle('FPS 표시', 'show_fps'),
            Button('완료', self.back),
        ]

    def back(self):
        self.app.save_options()
        self.app.open(self.parent)

    def place(self, w, h):
        s = self.s
        top = h // 6 - 12 * s
        for i, wd in enumerate(self.widgets[:-1]):
            col, row = i % 2, i // 2
            self.button(wd, w // 2 + (-80 if col == 0 else 80) * s, top + row * 24 * s, 150)
        self.button(self.widgets[-1], w // 2, h // 6 + 132 * s)

    def draw(self, surf, mouse):
        if self.app.session and not self.app.session.panorama:
            dim(surf, 150)
        else:
            dirt(surf, self.app.icons)
        self.title(surf, '설정', 15 * self.s)
        super().draw(surf, mouse)


class PauseScreen(Screen):
    def __init__(self, app):
        super().__init__(app)
        self.resume = Button('게임으로 돌아가기', app.close_screen)
        self.options = Button('설정...', lambda: app.open(SettingsScreen(app, self)))
        self.quit = Button('저장 후 타이틀 화면으로', app.leave_world)
        self.widgets = [self.resume, self.options, self.quit]

    def place(self, w, h):
        s = self.s
        self.button(self.resume, w // 2, h // 4 + 8 * s)
        self.button(self.options, w // 2, h // 4 + 56 * s)
        self.button(self.quit, w // 2, h // 4 + 104 * s)

    def draw(self, surf, mouse):
        dim(surf, 130)
        self.title(surf, '게임 메뉴', 40 * self.s)
        super().draw(surf, mouse)


class DeathScreen(Screen):
    CAUSES = {'fall': '너무 높은 곳에서 떨어졌습니다', 'drown': '익사했습니다',
              'void': '세계 밖으로 떨어졌습니다', 'kill': '죽었습니다'}

    def __init__(self, app, cause):
        super().__init__(app)
        self.cause = cause
        self.respawn = Button('리스폰', app.respawn)
        self.title_btn = Button('타이틀 화면', app.leave_world)
        self.widgets = [self.respawn, self.title_btn]

    def back(self):
        pass

    def place(self, w, h):
        s = self.s
        self.button(self.respawn, w // 2, h // 4 + 72 * s)
        self.button(self.title_btn, w // 2, h // 4 + 96 * s)

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        s = self.s
        g = _images.get(('death', w, h))
        if g is None:
            g = pg.Surface((w, h), pg.SRCALPHA)
            for y in range(h):
                t = y / h
                g.fill((int(80 + 40 * t), 0, 0, int(96 + 64 * t)), (0, y, w, 1))
            _images[('death', w, h)] = g
        surf.blit(g, (0, 0))
        f = fonts.font(font_px(s) * 2)
        img = fonts.render(f, '사망했습니다!', WHITE)
        sh = fonts.render(f, '사망했습니다!', (63, 63, 63))
        r = img.get_rect(center=(w // 2, 60 * s))
        surf.blit(sh, r.move(2 * s, 2 * s))
        surf.blit(img, r)
        text(surf, '플레이어가 ' + self.CAUSES.get(self.cause, '죽었습니다'), font_px(s),
             WHITE, center=(w // 2, 85 * s))
        super().draw(surf, mouse)


class LoadingScreen(Screen):
    def __init__(self, app, title, sub=''):
        super().__init__(app)
        self.title_text, self.sub = title, sub

    def draw(self, surf, mouse):
        w, h = surf.get_size()
        self.s = gui_scale(w, h)
        dirt(surf, self.app.icons)
        self.title(surf, self.title_text, h // 2 - 10 * self.s)
        if self.sub:
            text(surf, self.sub, font_px(self.s), GREY, center=(w // 2, h // 2 + 10 * self.s))


# ---------------------------------------------------------------------------
# Containers — inventory, crafting table, furnace
# ---------------------------------------------------------------------------

def draw_stack(surf, icons, stack, x, y, size, s):
    """An item stack with its count in the slot's bottom-right, as in the game."""
    if not stack:
        return
    icon = icons.get(stack[0], size)
    if icon:
        surf.blit(icon, (x, y))
    if stack[1] > 1:
        f = fonts.font(small_px(s))
        n = str(stack[1])
        img = fonts.render(f, n, WHITE)
        sh = fonts.render(f, n, (63, 63, 63))
        tx = x + size + s - img.get_width()
        ty = y + size + s - img.get_height() + s
        surf.blit(sh, (tx + s, ty + s))
        surf.blit(img, (tx, ty))


class ContainerScreen(Screen):
    """A GUI texture plus slots. Slot = (gx, gy, getter, setter, kind)."""
    texture = 'gui/inventory.png'
    title_label = ''
    title_pos = (8, 6)
    inventory_label = True

    def __init__(self, app, session):
        super().__init__(app)
        self.session = session
        self.inv = session.inventory
        self.cursor = None
        self.slots = []
        for i in range(27):
            r, c = divmod(i, 9)
            self.slots.append((8 + 18 * c, 84 + 18 * r, 9 + i, 'inv'))
        for c in range(9):
            self.slots.append((8 + 18 * c, 142, c, 'inv'))

    # slot storage -----------------------------------------------------
    def get(self, ref, kind):
        return self.inv.slots[ref] if kind == 'inv' else None

    def put(self, ref, kind, stack):
        if kind == 'inv':
            self.inv.slots[ref] = stack

    def take_result(self, ref, kind):
        """Called when a result slot is clicked. Returns the stack made."""
        return None

    def changed(self):
        self.session.sync_hotbar()

    # layout -------------------------------------------------------------
    def place(self, w, h):
        s = self.s
        self.ox = (w - 176 * s) // 2
        self.oy = (h - 166 * s) // 2

    def slot_rect(self, gx, gy):
        s = self.s
        return pg.Rect(self.ox + gx * s, self.oy + gy * s, 16 * s, 16 * s)

    def slot_at(self, pos):
        for gx, gy, ref, kind in self.slots:
            if self.slot_rect(gx, gy).inflate(2 * self.s, 2 * self.s).collidepoint(pos):
                return ref, kind
        return None

    def back(self):
        if self.cursor:
            self.inv.add(*self.cursor)
            self.cursor = None
        self.on_close()
        self.changed()
        self.app.close_screen()

    def on_close(self):
        pass

    # input --------------------------------------------------------------
    def event(self, e):
        if e.type == pg.KEYDOWN and e.key in (pg.K_e, pg.K_ESCAPE):
            self.back()
            return True
        if e.type != pg.MOUSEBUTTONDOWN or e.button not in (1, 3):
            return False
        hit = self.slot_at(e.pos)
        if hit is None:
            return False
        ref, kind = hit
        shift = pg.key.get_mods() & pg.KMOD_SHIFT

        if kind == 'result':
            self._click_result(ref, kind, shift)
        elif shift:
            self._quick_move(ref, kind)
        else:
            self._click_slot(ref, kind, e.button)
        self.changed()
        return True

    def _click_result(self, ref, kind, shift):
        for _ in range(64 if shift else 1):
            made = self.get(ref, kind)
            if not made:
                return
            if shift:
                stack = self.take_result(ref, kind)
                left = self.inv.add(stack[0], stack[1])
                if left:
                    self.cursor = [stack[0], left]
                    return
            else:
                cur = self.cursor
                if cur and (cur[0] != made[0] or cur[1] + made[1] > items.stack_limit(made[0])):
                    return
                stack = self.take_result(ref, kind)
                if cur:
                    cur[1] += stack[1]
                else:
                    self.cursor = list(stack)
                return

    def _quick_move(self, ref, kind):
        stack = self.get(ref, kind)
        if not stack:
            return
        self.put(ref, kind, None)
        if kind == 'inv' and ref < 9:
            targets = list(range(9, 36))
        elif kind == 'inv':
            targets = list(range(9))
        else:
            targets = list(range(9)) + list(range(9, 36))
        count = stack[1]
        limit = items.stack_limit(stack[0])
        for i in targets:
            s = self.inv.slots[i]
            if s and s[0] == stack[0] and s[1] < limit:
                move = min(count, limit - s[1])
                s[1] += move
                count -= move
        for i in targets:
            if count and self.inv.slots[i] is None:
                self.inv.slots[i] = [stack[0], count]
                count = 0
        if count:
            self.put(ref, kind, [stack[0], count])

    def _click_slot(self, ref, kind, button):
        s = self.get(ref, kind)
        cur = self.cursor
        if button == 1:
            if cur and s and cur[0] == s[0]:
                move = max(0, min(cur[1], items.stack_limit(s[0]) - s[1]))
                s[1] += move
                cur[1] -= move
                self.cursor = cur if cur[1] else None
            else:
                self.put(ref, kind, cur)
                self.cursor = s
        else:
            if cur is None and s:
                half = (s[1] + 1) // 2
                self.cursor = [s[0], half]
                s[1] -= half
                if not s[1]:
                    self.put(ref, kind, None)
            elif cur and (s is None or (s[0] == cur[0] and s[1] < items.stack_limit(s[0]))):
                if s is None:
                    self.put(ref, kind, [cur[0], 1])
                else:
                    s[1] += 1
                cur[1] -= 1
                self.cursor = cur if cur[1] else None

    # drawing --------------------------------------------------------------
    def draw_extra(self, surf):
        pass

    def draw(self, surf, mouse):
        s = self.s
        dim(surf, 120)
        tex = scaled(self.texture, (256 * s, 256 * s))
        if tex:
            surf.blit(tex, (self.ox, self.oy), (0, 0, 176 * s, 166 * s))
        fs = small_px(s)
        if self.title_label:
            text(surf, self.title_label, fs, LABEL, shadow=False,
                 topleft=(self.ox + self.title_pos[0] * s, self.oy + self.title_pos[1] * s))
        if self.inventory_label:
            text(surf, '인벤토리', fs, LABEL, shadow=False,
                 topleft=(self.ox + 8 * s, self.oy + 72 * s))
        self.draw_extra(surf)

        hover = None
        for gx, gy, ref, kind in self.slots:
            r = self.slot_rect(gx, gy)
            draw_stack(surf, self.app.icons, self.get(ref, kind), r.x, r.y, r.w, s)
            if r.inflate(2 * s, 2 * s).collidepoint(mouse):
                hl = pg.Surface(r.size, pg.SRCALPHA)
                hl.fill((255, 255, 255, 128))
                surf.blit(hl, r)
                hover = self.get(ref, kind)
        if self.cursor:
            size = 16 * s
            draw_stack(surf, self.app.icons, self.cursor, mouse[0] - size // 2,
                       mouse[1] - size // 2, size, s)
        elif hover:
            self.tooltip(surf, items.display_name(hover[0], '?'), mouse)

    def tooltip(self, surf, label, mouse):
        s = self.s
        f = fonts.font(font_px(s))
        img = fonts.render(f, label, WHITE)
        r = img.get_rect(topleft=(mouse[0] + 12 * s, mouse[1] - 12 * s)).inflate(6 * s, 6 * s)
        surf.fill((16, 0, 16), r)
        pg.draw.rect(surf, (40, 2, 100), r.inflate(-2 * s, -2 * s), s)
        surf.blit(img, img.get_rect(center=r.center))


class CraftingContainer(ContainerScreen):
    """Shared by the 2x2 grid in the inventory and the 3x3 crafting table."""
    size = 2
    grid_at = (98, 18)
    result_at = (154, 28)

    def __init__(self, app, session):
        super().__init__(app, session)
        self.grid = [None] * (self.size * self.size)
        gx, gy = self.grid_at
        for i in range(self.size * self.size):
            r, c = divmod(i, self.size)
            self.slots.append((gx + 18 * c, gy + 18 * r, i, 'grid'))
        self.slots.append((self.result_at[0], self.result_at[1], 0, 'result'))

    def ids(self):
        return [g[0] if g else 0 for g in self.grid]

    def get(self, ref, kind):
        if kind == 'grid':
            return self.grid[ref]
        if kind == 'result':
            made = crafting.craft(self.ids(), self.size)
            return list(made) if made else None
        return super().get(ref, kind)

    def put(self, ref, kind, stack):
        if kind == 'grid':
            self.grid[ref] = stack
        elif kind != 'result':
            super().put(ref, kind, stack)

    def take_result(self, ref, kind):
        made = crafting.craft(self.ids(), self.size)
        if not made:
            return None
        for i, g in enumerate(self.grid):
            if g:
                g[1] -= 1
                if g[1] <= 0:
                    self.grid[i] = None
        return list(made)

    def on_close(self):
        for g in self.grid:
            if g:
                self.inv.add(*g)
        self.grid = [None] * len(self.grid)


class InventoryScreen(CraftingContainer):
    texture = 'gui/inventory.png'
    title_label = '제작'
    title_pos = (97, 6)
    inventory_label = False

    def draw_extra(self, surf):
        # The player-model window: there is no player model, so the panorama
        # shows through a dark glass instead of a black hole.
        s = self.s
        r = pg.Rect(self.ox + 26 * s, self.oy + 8 * s, 49 * s, 70 * s)
        surf.fill((22, 22, 30), r)
        text(surf, 'Python', font_px(s), (90, 90, 120), center=(r.centerx, r.centery - 6 * s), shadow=False)
        text(surf, 'Edition', font_px(s), (90, 90, 120), center=(r.centerx, r.centery + 8 * s), shadow=False)


class CraftingTableScreen(CraftingContainer):
    texture = 'gui/crafting_table.png'
    title_label = '제작'
    title_pos = (29, 6)
    size = 3
    grid_at = (30, 17)
    result_at = (124, 35)


class FurnaceScreen(ContainerScreen):
    texture = 'gui/smoker.png'
    title_label = '화로'
    title_pos = (70, 6)

    def __init__(self, app, session, state):
        super().__init__(app, session)
        self.state = state
        self.slots += [(56, 17, 'in', 'furnace'), (56, 53, 'fuel', 'furnace'),
                       (116, 35, 'out', 'furnace_out')]
        self.pauses = False           # the furnace keeps cooking behind it

    def get(self, ref, kind):
        if kind in ('furnace', 'furnace_out'):
            return self.state[ref]
        return super().get(ref, kind)

    def put(self, ref, kind, stack):
        if kind == 'furnace':
            self.state[ref] = stack
        elif kind == 'furnace_out':
            if stack is None:
                self.state[ref] = None
        else:
            super().put(ref, kind, stack)

    def _click_slot(self, ref, kind, button):
        if kind == 'furnace_out':
            out = self.state['out']
            if out and (self.cursor is None or (self.cursor[0] == out[0]
                                                and self.cursor[1] + out[1] <= 64)):
                if self.cursor:
                    self.cursor[1] += out[1]
                else:
                    self.cursor = out
                self.state['out'] = None
            return
        super()._click_slot(ref, kind, button)

    def draw_extra(self, surf):
        # The flame and the arrow are drawn in the texture as grey outlines;
        # progress repaints the part that is done, from the bottom (flame) or
        # the left (arrow), the way the real furnace fills them.
        s = self.s
        st = self.state
        if st['burn'] > 0 and st['burn_max'] > 0:
            frac = st['burn'] / st['burn_max']
            self._fill(surf, (56, 36, 14, 14), (255, 140, 20), frac, vertical=True)
        if st['cook'] > 0:
            frac = min(1.0, st['cook'] / crafting.SMELT_TIME)
            self._fill(surf, (79, 34, 24, 17), (255, 255, 255), frac, vertical=False)

    def _fill(self, surf, rect, color, frac, vertical):
        s = self.s
        x, y, w, h = rect
        base = image(self.texture)
        if base is None:
            return
        key = ('fill', self.texture, rect, color)
        lit = _images.get(key)
        if lit is None:
            src = base.subsurface(rect).copy()
            lit = pg.Surface((w, h), pg.SRCALPHA)
            for py in range(h):
                for px in range(w):
                    r, g, b, a = src.get_at((px, py))
                    if a and r < 175 and abs(r - g) < 8 and abs(g - b) < 8:   # the grey sprite
                        lit.set_at((px, py), color + (255,))
            _images[key] = lit
        if vertical:
            cut = int(round(h * frac))
            if cut <= 0:
                return
            part = lit.subsurface((0, h - cut, w, cut))
            surf.blit(pg.transform.scale(part, (w * s, cut * s)),
                      (self.ox + x * s, self.oy + (y + h - cut) * s))
        else:
            cut = int(round(w * frac))
            if cut <= 0:
                return
            part = lit.subsurface((0, 0, cut, h))
            surf.blit(pg.transform.scale(part, (cut * s, h * s)),
                      (self.ox + x * s, self.oy + y * s))


# ---------------------------------------------------------------------------
# Pixel art for the survival HUD
# ---------------------------------------------------------------------------

_HEART = ('.XX.XX.', 'XXXXXXX', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...')
_BUBBLE = ('..XXX..', '.X...X.', 'X..O..X', 'X.....X', '.X...X.', '..XXX..')


def heart(surf, x, y, s, fill):
    """fill: 2 full, 1 half, 0 empty."""
    for r, row in enumerate(_HEART):
        for c, ch in enumerate(row):
            if ch == 'X':
                surf.fill((0, 0, 0, 255), (x + c * s, y + r * s, s + s, s + s))
    for r, row in enumerate(_HEART):
        for c, ch in enumerate(row):
            if ch != 'X':
                continue
            red = fill == 2 or (fill == 1 and c <= 3)
            color = (220, 20, 30) if red else (60, 20, 20)
            if red and r == 1 and c in (1, 2):
                color = (255, 160, 160)
            surf.fill(color + (255,), (x + c * s + s // 2, y + r * s + s // 2, s, s))


def bubble(surf, x, y, s):
    for r, row in enumerate(_BUBBLE):
        for c, ch in enumerate(row):
            if ch == 'X':
                surf.fill((30, 60, 160, 255), (x + c * s, y + r * s, s, s))
            elif ch == 'O':
                surf.fill((220, 240, 255, 255), (x + c * s, y + r * s, s, s))
            elif 1 <= r <= 4 and 1 <= c <= 5:
                surf.fill((120, 180, 255, 200), (x + c * s, y + r * s, s, s))


# ---------------------------------------------------------------------------
# Creative inventory — built from assets/gui/tab_inventory.png
# ---------------------------------------------------------------------------

class CreativeScreen(Screen):
    """The real game's creative inventory: category tabs above and below the
    panel, a 9x5 item grid with a scrollbar, the hotbar underneath and a bin.

    The panel is the provided tab_inventory.png with its top half repainted
    into the item grid, using that texture's own slot sprite — so every slot,
    edge and colour is the game's GUI, not a drawing of it.
    Clicking an item picks it up, clicking a hotbar slot puts it there, shift
    clicking or pressing 1-9 over an item sends it straight to the hotbar, and
    on the first tab typing searches every block by name.
    """
    COLS, ROWS = 9, 5
    TAB_W, TAB_H = 26, 28
    TOP_TABS = 8

    def __init__(self, app, session):
        super().__init__(app)
        from engine.hud import TABS
        self.session = session
        item_ids = sorted(items.ITEMS)
        self.tabs = ([(TABS[0][0], list(TABS[0][1]) + item_ids)] + list(TABS[1:])
                     + [('도구·아이템', item_ids)])
        self.tab = 0
        self.query = ''
        self.scroll = 0
        self.cursor = None
        self.items = []
        self.refilter()

    # data ---------------------------------------------------------------
    def refilter(self):
        name, ids = self.tabs[self.tab]
        if self.query:
            q = self.query.lower().replace(' ', '')
            ids = [b for b in self.tabs[0][1]
                   if q in items.display_name(b).lower().replace(' ', '')]
        self.items = ids
        self.scroll = min(self.scroll, self.max_scroll())

    def max_scroll(self):
        rows = (len(self.items) + self.COLS - 1) // self.COLS
        return max(0, rows - self.ROWS)

    # layout -------------------------------------------------------------
    def place(self, w, h):
        s = self.s
        self.ox = (w - 195 * s) // 2
        self.oy = (h - 136 * s) // 2

    def panel(self):
        key = ('creative_panel',)
        img = _images.get(key)
        if img is None:
            base = image('gui/tab_inventory.png')
            if base is None:
                return None
            img = base.subsurface((0, 0, 195, 136)).copy()
            slot = base.subsurface((8, 53, 18, 18)).copy()
            img.fill((198, 198, 198, 255), (4, 4, 187, 104))
            for r in range(self.ROWS):
                for c in range(self.COLS):
                    img.blit(slot, (8 + 18 * c, 17 + 18 * r))
            # scrollbar well
            img.fill((55, 55, 55, 255), (174, 17, 14, 91))
            img.fill((139, 139, 139, 255), (175, 18, 12, 89))
            img.fill((255, 255, 255, 255), (175, 107, 13, 1))
            img.fill((255, 255, 255, 255), (187, 18, 1, 90))
            _images[key] = img
        return img

    def r(self, gx, gy, gw, gh):
        s = self.s
        return pg.Rect(self.ox + gx * s, self.oy + gy * s, gw * s, gh * s)

    def tab_rect(self, i):
        if i < self.TOP_TABS:
            return self.r(i * (self.TAB_W + 1), -self.TAB_H + 4, self.TAB_W, self.TAB_H)
        j = i - self.TOP_TABS
        return self.r(j * (self.TAB_W + 1), 136 - 4, self.TAB_W, self.TAB_H)

    def grid_rect(self, r, c):
        return self.r(9 + 18 * c, 18 + 18 * r, 16, 16)

    def hotbar_rect(self, i):
        return self.r(9 + 18 * i, 112, 16, 16)

    # input --------------------------------------------------------------
    def back(self):
        self.cursor = None
        self.session.sync_hotbar()
        self.app.close_screen()

    def hovered_item(self, pos):
        for r in range(self.ROWS):
            for c in range(self.COLS):
                if self.grid_rect(r, c).inflate(2 * self.s, 2 * self.s).collidepoint(pos):
                    i = (self.scroll + r) * self.COLS + c
                    return self.items[i] if i < len(self.items) else None
        return None

    def event(self, e):
        hb = self.session.creative_hotbar
        if e.type == pg.KEYDOWN:
            if e.key == pg.K_ESCAPE or (e.key == pg.K_e and self.tab != 0):
                self.back()
                return True
            if e.key == pg.K_BACKSPACE and self.query:
                self.query = self.query[:-1]
                self.refilter()
                return True
            if pg.K_1 <= e.key <= pg.K_9:
                item = self.hovered_item(pg.mouse.get_pos())
                if item is not None:
                    hb[e.key - pg.K_1] = item
                    return True
            return False
        if e.type == pg.TEXTINPUT and self.tab == 0:
            if e.text.isdigit() and self.hovered_item(pg.mouse.get_pos()) is not None:
                return True
            self.query = (self.query + e.text)[:24]
            self.scroll = 0
            self.refilter()
            return True
        if e.type == pg.MOUSEWHEEL:
            self.scroll = min(max(0, self.scroll - e.y), self.max_scroll())
            return True
        if e.type == pg.MOUSEMOTION and e.buttons[0] and getattr(self, 'dragging', False):
            self._drag(e.pos)
            return True
        if e.type == pg.MOUSEBUTTONUP:
            self.dragging = False
            return False
        if e.type != pg.MOUSEBUTTONDOWN or e.button not in (1, 3):
            return False
        pos = e.pos
        for i in range(len(self.tabs)):
            if self.tab_rect(i).collidepoint(pos):
                self.tab, self.scroll = i, 0
                if i != 0:
                    self.query = ''
                self.refilter()
                return True
        if self.r(174, 17, 14, 91).collidepoint(pos):
            self.dragging = True
            self._drag(pos)
            return True
        item = self.hovered_item(pos)
        if item is not None:
            if pg.key.get_mods() & pg.KMOD_SHIFT:
                hb[self.session.hotbar_slot] = item
            else:
                self.cursor = None if self.cursor else item
            return True
        for i in range(9):
            if self.hotbar_rect(i).inflate(2 * self.s, 2 * self.s).collidepoint(pos):
                hb[i], self.cursor = (self.cursor or 0), (hb[i] or None)
                return True
        if self.r(173, 111, 18, 18).collidepoint(pos):          # the bin
            self.cursor = None
            return True
        return False

    def _drag(self, pos):
        top, height = self.oy + 18 * self.s, 89 * self.s
        frac = min(max((pos[1] - top) / height, 0.0), 1.0)
        self.scroll = int(round(frac * self.max_scroll()))

    # drawing --------------------------------------------------------------
    def draw_tab(self, surf, i, mouse):
        s = self.s
        rect = self.tab_rect(i)
        selected = i == self.tab
        top = i < self.TOP_TABS
        face = (198, 198, 198) if selected else (139, 139, 139)
        surf.fill((0, 0, 0), rect)
        inner = rect.inflate(-2 * s, -2 * s)
        surf.fill(face, inner)
        surf.fill((255, 255, 255) if selected else (170, 170, 170), (inner.x, inner.y, inner.w, s))
        surf.fill((255, 255, 255) if selected else (170, 170, 170), (inner.x, inner.y, s, inner.h))
        surf.fill((85, 85, 85), (inner.right - s, inner.y, s, inner.h))
        if selected:   # merge into the panel edge
            edge = (inner.x, rect.bottom - 4 * s, inner.w, 5 * s) if top else (inner.x, rect.y - s, inner.w, 5 * s)
            surf.fill(face, edge)
        ids = self.tabs[i][1]
        icon_block = 1 if i == 0 else (ids[0] if ids else None)
        if icon_block is not None:
            icon = self.app.icons.get(icon_block, 16 * s)
            if icon:
                surf.blit(icon, icon.get_rect(center=(rect.centerx, rect.centery + (s if top else -s))))
        if rect.collidepoint(mouse):
            self.tip = self.tabs[i][0]

    def draw(self, surf, mouse):
        s = self.s
        dim(surf, 120)
        self.tip = None
        for i in range(len(self.tabs)):
            if i != self.tab:
                self.draw_tab(surf, i, mouse)
        panel = self.panel()
        if panel:
            surf.blit(pg.transform.scale(panel, (195 * s, 136 * s)), (self.ox, self.oy))
        self.draw_tab(surf, self.tab, mouse)

        fs = small_px(s)
        name = self.tabs[self.tab][0]
        text(surf, '검색' if self.tab == 0 else name, fs, LABEL, shadow=False,
             topleft=(self.ox + 8 * s, self.oy + 5 * s))
        if self.tab == 0:
            box = self.r(82, 5, 88, 11)
            surf.fill((160, 160, 160), box)
            surf.fill((0, 0, 0), box.inflate(-2 * s, -2 * s))
            caret = '_' if int(time.time() * 3) % 2 == 0 else ''
            shown = self.query + caret if self.query or caret else ''
            text(surf, shown or '블록 이름 입력', fs, WHITE if self.query else (110, 110, 110),
                 midleft=(box.x + 3 * s, box.centery), shadow=False)

        hover = None
        for r in range(self.ROWS):
            for c in range(self.COLS):
                i = (self.scroll + r) * self.COLS + c
                rect = self.grid_rect(r, c)
                if i < len(self.items):
                    icon = self.app.icons.get(self.items[i], rect.w)
                    if icon:
                        surf.blit(icon, rect)
                if rect.inflate(2 * s, 2 * s).collidepoint(mouse):
                    self._highlight(surf, rect)
                    if i < len(self.items):
                        hover = self.items[i]
        hb = self.session.creative_hotbar
        for i in range(9):
            rect = self.hotbar_rect(i)
            if hb[i]:
                icon = self.app.icons.get(hb[i], rect.w)
                if icon:
                    surf.blit(icon, rect)
            if rect.inflate(2 * s, 2 * s).collidepoint(mouse):
                self._highlight(surf, rect)
                if hb[i]:
                    hover = hb[i]

        # scrollbar thumb
        ms = self.max_scroll()
        ty = 18 + (0 if ms == 0 else int((89 - 15) * self.scroll / ms))
        thumb = self.r(175, ty, 12, 15)
        draw_button(surf, thumb, '', False, ms > 0, s)

        if self.cursor:
            size = 16 * s
            icon = self.app.icons.get(self.cursor, size)
            if icon:
                surf.blit(icon, (mouse[0] - size // 2, mouse[1] - size // 2))
        elif hover is not None:
            self.tooltip(surf, items.display_name(hover, '?'), mouse)
        elif self.tip:
            self.tooltip(surf, self.tip, mouse)

    def _highlight(self, surf, rect):
        hl = pg.Surface(rect.size, pg.SRCALPHA)
        hl.fill((255, 255, 255, 128))
        surf.blit(hl, rect)

    tooltip = ContainerScreen.tooltip
