"""Items that are not blocks: sticks, ingots, tools, food.

They share the inventory with blocks, so they need ids that can never be a
block's: everything here is ITEM_BASE or above. A stack is still
`[id, count]`; `is_item(id)` is how the rest of the game tells the two apart.

Tool numbers follow the real game (Minecraft Wiki, "Tiers"): mining speed
wood 2, stone 4, copper 5, iron 6, diamond 8, netherite 9; sword damage in
half-hearts wood 4, stone 5, copper 5, iron 6, diamond 7, netherite 8.
"""

import os

ITEM_BASE = 5000
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ITEM_DIR = os.path.join(_HERE, 'assets', 'items')


class Item:
    def __init__(self, key, name, kind='material', tier=0, speed=1.0,
                 damage=1, heal=0, stack=64):
        self.key, self.name, self.kind = key, name, kind
        self.tier, self.speed, self.damage = tier, speed, damage
        self.heal, self.stack = heal, stack
        self.texture = os.path.join(ITEM_DIR, key + '.png')


_DEFS = [
    Item('stick', 'Stick'),
    Item('coal', 'Coal'),
    Item('iron_ingot', 'Iron Ingot'),
    Item('gold_ingot', 'Gold Ingot'),
    Item('copper_ingot', 'Copper Ingot'),
    Item('diamond', 'Diamond'),
    Item('netherite_scrap', 'Netherite Scrap'),
    Item('netherite_ingot', 'Netherite Ingot'),
    Item('porkchop', 'Raw Porkchop', 'food', heal=2),
    Item('cooked_porkchop', 'Cooked Porkchop', 'food', heal=8),
    Item('baked_potato', 'Baked Potato', 'food', heal=5),
    Item('rotten_flesh', 'Rotten Flesh', 'food', heal=1),
]
# tier: what the pickaxe can harvest. 1 stone & coal, 2 iron/copper/lapis,
# 3 gold/diamond/redstone/emerald, 4 obsidian and ancient debris.
for material, tier, speed, damage in (('wooden', 1, 2.0, 4), ('stone', 2, 4.0, 5),
                                      ('copper', 2, 5.0, 5), ('iron', 3, 6.0, 6),
                                      ('diamond', 4, 8.0, 7), ('netherite', 4, 9.0, 8)):
    title = material.capitalize()
    _DEFS.append(Item(f'{material}_pickaxe', f'{title} Pickaxe', 'pickaxe',
                      tier, speed, max(2, damage - 2), stack=1))
    _DEFS.append(Item(f'{material}_sword', f'{title} Sword', 'sword',
                      tier, 1.5, damage, stack=1))

ITEMS = {ITEM_BASE + i: d for i, d in enumerate(_DEFS)}
BY_KEY = {d.key: iid for iid, d in ITEMS.items()}


def is_item(bid):
    return bid is not None and int(bid) >= ITEM_BASE


def get(bid):
    return ITEMS.get(int(bid)) if bid else None


def item_id(key):
    return BY_KEY[key]


def name(bid):
    it = get(bid)
    return it.name if it else None


def stack_limit(bid):
    it = get(bid)
    return it.stack if it else 64


def display_name(bid, default=''):
    """The name shown for any id in a slot: an item's, else the block's."""
    if not bid:
        return default
    if is_item(bid):
        it = get(bid)
        return it.name if it else default
    from world.blocks import BLOCK_NAMES
    return BLOCK_NAMES.get(int(bid), default)
