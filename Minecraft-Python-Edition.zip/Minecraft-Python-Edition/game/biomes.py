"""Biome colours for grass and leaves, and the map that carries them to the
chunk shader.

Colours are the real game's per-biome grass / foliage colours (the values the
Minecraft Wiki lists for each biome). The map is a lattice of biome samples
four blocks apart around the player, blurred so one biome fades into the next
over a dozen blocks, uploaded as two small textures and read with linear
filtering — which is the real game's "biome blend" done on the GPU.
"""

import threading

import moderngl as mgl
import numpy as np

from world import terrain_generator as tg


def _hex(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


#            biome name        grass     foliage
COLORS = {
    'Ocean': ('8EB971', '71A74D'), 'Deep Ocean': ('8EB971', '71A74D'),
    'Frozen Ocean': ('80B497', '60A17B'), 'Warm Ocean': ('8EB971', '71A74D'),
    'Beach': ('91BD59', '77AB2F'), 'Snowy Beach': ('83B593', '64A278'),
    'Stony Shore': ('8AB689', '6DA36B'), 'River': ('8EB971', '71A74D'),
    'Plains': ('91BD59', '77AB2F'), 'Forest': ('79C05A', '59AE30'),
    'Birch Forest': ('88BB67', '6BA941'), 'Dark Forest': ('507A32', '59AE30'),
    'Taiga': ('86B783', '68A464'), 'Snowy Taiga': ('80B497', '60A17B'),
    'Snowy Plains': ('80B497', '60A17B'), 'Savanna': ('BFB755', 'AEA42A'),
    'Desert': ('BFB755', 'AEA42A'), 'Jungle': ('59C93C', '30BB0B'),
    'Swamp': ('6A7039', '6A7039'), 'Badlands': ('90814D', '9E814D'),
    'Windswept Hills': ('8AB689', '6DA36B'), 'Meadow': ('83BB6D', '63A948'),
    'Grove': ('80B497', '60A17B'), 'Snowy Slopes': ('80B497', '60A17B'),
    'Jagged Peaks': ('80B497', '60A17B'), 'Stony Peaks': ('9ABE4B', '82AC1E'),
    'Pale Garden': ('778272', '878D76'),
}
GRASS = np.array([_hex(COLORS.get(n, ('91BD59', '77AB2F'))[0]) for n in tg.BIOME_NAMES],
                 dtype=np.float32) / 255.0
FOLIAGE = np.array([_hex(COLORS.get(n, ('91BD59', '77AB2F'))[1]) for n in tg.BIOME_NAMES],
                   dtype=np.float32) / 255.0

STEP = 4            # blocks between samples: the climate lattice's own step
SIZE = 192          # samples per side: 764 blocks, past any fog at 24 chunks
RECENTER = 160      # blocks the player may wander before the map moves


def _blur(a, passes=2):
    for _ in range(passes):
        p = np.pad(a, ((1, 1), (1, 1), (0, 0)), mode='edge')
        a = (p[:-2, :-2] + p[:-2, 1:-1] + p[:-2, 2:] + p[1:-1, :-2] + p[1:-1, 1:-1]
             + p[1:-1, 2:] + p[2:, :-2] + p[2:, 1:-1] + p[2:, 2:]) / 9.0
    return a


class BiomeMap:
    """Owns the two textures; rebuilds them off the main thread as you move."""

    def __init__(self, renderer):
        self.renderer = renderer
        ctx = renderer.ctx
        self.grass_tex = ctx.texture((SIZE, SIZE), 3, dtype='f1')
        self.foliage_tex = ctx.texture((SIZE, SIZE), 3, dtype='f1')
        for t in (self.grass_tex, self.foliage_tex):
            t.filter = (mgl.LINEAR, mgl.LINEAR)
            t.repeat_x = t.repeat_y = False
        self.center = None
        self.pending = None          # (origin, grass, foliage) from the worker
        self.busy = False
        self.rect = (0.0, 0.0, 0.0, float(SIZE))
        self._upload_rect(0.0)

    def _compute(self, cx, cz):
        x0 = int(cx) - (SIZE // 2) * STEP
        z0 = int(cz) - (SIZE // 2) * STEP
        ids = tg.biome_ids(x0, z0, STEP, SIZE)
        grass = _blur(GRASS[ids])
        foliage = _blur(FOLIAGE[ids])
        return (x0, z0), grass, foliage

    def _worker(self, cx, cz):
        try:
            self.pending = self._compute(cx, cz)
        finally:
            self.busy = False

    def update(self, pos, block=False):
        """Call every frame with the player position."""
        if self.pending is not None:
            (x0, z0), grass, foliage = self.pending
            self.pending = None
            # texel (i, j) is x0 + i*STEP, z0 + j*STEP: GL wants rows along z
            self.grass_tex.write((np.transpose(grass, (1, 0, 2)) * 255).astype('u1').tobytes())
            self.foliage_tex.write((np.transpose(foliage, (1, 0, 2)) * 255).astype('u1').tobytes())
            self.rect = (float(x0), float(z0), float(STEP * (SIZE - 1)), float(SIZE))
            self._upload_rect(self.rect[2])
        far = (self.center is None or abs(pos.x - self.center[0]) > RECENTER
               or abs(pos.z - self.center[1]) > RECENTER)
        if far and not self.busy:
            self.center = (pos.x, pos.z)
            if block:
                self.pending = self._compute(pos.x, pos.z)
                self.update(pos)
            else:
                self.busy = True
                threading.Thread(target=self._worker, args=(pos.x, pos.z), daemon=True).start()

    def _upload_rect(self, span):
        r = self.renderer
        for program in r.chunk_programs:
            if 'u_grass_map' in program:
                program['u_grass_map'] = 8
            if 'u_foliage_map' in program:
                program['u_foliage_map'] = 9
            if 'u_biome_rect' in program:
                program['u_biome_rect'] = (self.rect[0], self.rect[1], span, self.rect[3])

    def bind(self):
        self.grass_tex.use(8)
        self.foliage_tex.use(9)

    def release(self):
        self.grass_tex.release()
        self.foliage_tex.release()
