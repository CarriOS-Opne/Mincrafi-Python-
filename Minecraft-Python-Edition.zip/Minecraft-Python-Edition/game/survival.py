"""Survival rules: how long a block takes to break, what it drops, the
inventory it drops into, and the player's health and air.

No crafting and no item that is not a block — everything you mine is a block
you can place again. That keeps survival honest (you build with what you dug)
without a second item registry beside the 677 blocks.
"""

import random

from world.blocks import (BLOCK_NAMES, COLLIDES, FACING, HIDDEN, ICON_LAYER,
                          LOWER)
from game import items

AIR, WATER = 0, 8
STACK = 64
HOTBAR = 9
SLOTS = 36                       # 9 hotbar + 27 backpack

MAX_HEALTH = 20                  # half-hearts
MAX_AIR = 15.0                   # seconds of breath
SAFE_FALL = 3.0                  # metres fallen for free
REGEN_DELAY = 4.0                # seconds without damage before healing starts
REGEN_STEP = 2.5                 # seconds per half-heart healed

_ID = {}
for _bid in sorted(BLOCK_NAMES):          # the pickable block, not a facing variant
    if _bid not in HIDDEN:
        _ID.setdefault(BLOCK_NAMES[_bid], _bid)

# facing variant -> the block it was placed as
_BASE = {v: base for base, row in FACING.items() for v in row}


# ---------------------------------------------------------------------------
# Breaking
# ---------------------------------------------------------------------------

_UNBREAKABLE = ('Bedrock', 'Reinforced Deepslate', 'Barrier', 'End Portal',
                'Command Block', 'Structure Block', 'Jigsaw', 'Light')

_RULES = (   # (seconds by hand, words any of which in the name match)
    (6.0, ('Obsidian',)),
    (0.05, ('Torch', 'Flower', 'Sapling', 'Mushroom', 'Fern', 'Short Grass',
            'Tall Grass', 'Dead Bush', 'Seagrass', 'Kelp', 'Wheat', 'Carrots',
            'Potatoes', 'Beetroots', 'Petals', 'Leaf Litter', 'Rail', 'Button')),
    (0.25, ('Leaves', 'Carpet', 'Snow', 'Vine', 'Ladder', 'Cobweb', 'Pressure Plate')),
    (0.4, ('Glass', 'Ice', 'Glowstone', 'Sea Lantern', 'Pane', 'Lantern', 'Froglight')),
    (0.5, ('Dirt', 'Grass Block', 'Sand', 'Gravel', 'Clay', 'Podzol', 'Mycelium',
           'Mud', 'Soul', 'Farmland', 'Path', 'Powder', 'Moss', 'Sponge', 'Hay',
           'Melon', 'Pumpkin', 'Cactus', 'Sugar Cane', 'Netherrack', 'Wart')),
    (0.7, ('Wool', 'Bed', 'Sculk', 'Coral')),
    (1.4, ('Log', 'Wood', 'Planks', 'Stem', 'Hyphae', 'Bookshelf', 'Table',
           'Chest', 'Barrel', 'Door', 'Fence', 'Trapdoor', 'Sign', 'Composter',
           'Loom', 'Lectern', 'Bamboo', 'Beehive', 'Bee Nest', 'Jukebox')),
    (2.4, ('Deepslate', 'Ore')),
    (1.8, ('Stone', 'Cobble', 'Brick', 'Andesite', 'Diorite', 'Granite', 'Tuff',
           'Calcite', 'Basalt', 'Blackstone', 'Terracotta', 'Concrete', 'Prismarine',
           'Quartz', 'Copper', 'Iron', 'Gold', 'Diamond', 'Emerald', 'Lapis',
           'Redstone', 'Coal', 'Furnace', 'Smoker', 'Anvil', 'Purpur', 'Dripstone',
           'Amethyst')),
)


def _hardness(name):
    if any(word in name for word in _UNBREAKABLE):
        return None
    for seconds, words in _RULES:
        if any(word in name for word in words):
            return seconds
    return 1.0


HARDNESS = {bid: _hardness(name) for bid, name in BLOCK_NAMES.items()}


# Blocks that want a pickaxe, after the real game: by hand they take five
# times their hardness and drop nothing; with a pickaxe of a high enough tier
# they take 1.5x hardness divided by its speed (Minecraft Wiki, "Breaking").
_PICK_WORDS = ('Stone', 'Cobble', 'Brick', 'Andesite', 'Diorite', 'Granite', 'Tuff',
               'Calcite', 'Sandstone', 'Terracotta', 'Basalt', 'Blackstone',
               'Netherrack', 'Prismarine', 'Quartz', 'Dripstone', 'Amethyst', 'Purpur',
               'Deepslate', 'Ore', 'Obsidian', 'Debris', 'Furnace', 'Smoker', 'Anvil',
               'Block of', 'Netherite', 'Lantern', 'Cauldron', 'Bell')
_NOT_PICK = ('Glowstone', 'Powder', 'Button', 'Pressure Plate', 'Redstone Wire')


def _needs_pickaxe(name):
    if any(w in name for w in _NOT_PICK):
        return False
    return any(w in name for w in _PICK_WORDS) or name.startswith('Concrete') \
        or name.endswith(' Concrete') or 'Copper' in name


def _pick_hardness(name):
    if 'Obsidian' in name or 'Netherite' in name:
        return 50.0
    if 'Ancient Debris' in name:
        return 30.0
    if name.endswith(' Ore'):
        return 4.5 if 'Deepslate' in name else 3.0
    if name.startswith('Block of'):
        return 5.0
    if 'Deepslate' in name:
        return 3.5
    if 'Furnace' in name or 'Smoker' in name:
        return 3.5
    if 'Cobble' in name or 'Brick' in name:
        return 2.0
    if 'Netherrack' in name:
        return 0.4
    if 'Calcite' in name or 'Sandstone' in name or 'Quartz' in name:
        return 0.8
    return 1.5


def _need_tier(name):
    if any(w in name for w in ('Obsidian', 'Ancient Debris', 'Netherite')):
        return 4
    if any(w in name for w in ('Diamond', 'Emerald', 'Gold', 'Redstone Ore')):
        return 3
    if any(w in name for w in ('Iron', 'Copper', 'Lapis')):
        return 2
    return 1


PICKAXE = {bid: _needs_pickaxe(n) for bid, n in BLOCK_NAMES.items()}


def _tool(tool_id):
    it = items.get(tool_id) if items.is_item(tool_id) else None
    return it


def can_harvest(block, tool_id=None):
    """Would breaking *block* with *tool_id* in hand drop anything?"""
    block = int(block)
    if not PICKAXE.get(block):
        return True
    t = _tool(tool_id)
    return t is not None and t.kind == 'pickaxe' and t.tier >= _need_tier(BLOCK_NAMES[block])


def break_time(block, tool_id=None):
    """Seconds to break *block* with *tool_id* in hand (None = by hand), or
    None if it cannot be broken at all."""
    block = int(block)
    if block in (AIR, WATER):
        return None
    t = HARDNESS.get(block, 1.0)
    if t is None:
        return None
    if not COLLIDES[block]:
        return min(t, 0.05)          # anything you walk through pops instantly
    if PICKAXE.get(block):
        hardness = _pick_hardness(BLOCK_NAMES[block])
        tool = _tool(tool_id)
        speed = tool.speed if tool is not None and tool.kind == 'pickaxe' else 1.0
        if can_harvest(block, tool_id):
            return hardness * 1.5 / speed
        return hardness * 5.0 / speed
    return t


# ---------------------------------------------------------------------------
# Drops
# ---------------------------------------------------------------------------

def _id(name):
    return _ID.get(name)


_DROP_AS = {
    'Stone': 'Cobblestone', 'Grass Block': 'Dirt', 'Snowy Grass Block': 'Dirt',
    'Podzol': 'Dirt', 'Mycelium': 'Dirt', 'Farmland': 'Dirt',
    'Moist Farmland': 'Dirt', 'Dirt Path': 'Dirt', 'Deepslate': 'Cobbled Deepslate',
}
# What breaks into nothing by hand, as in the real game without silk touch.
_DROP_NOTHING_WORDS = ('Glass', 'Leaves', 'Short Grass', 'Tall Grass', 'Fern',
                       'Seagrass', 'Cobweb', 'Dead Bush')
_DROP_NOTHING_NAMES = {'Ice', 'Budding Amethyst'}


_DROP_ITEM = {'Coal Ore': 'coal', 'Deepslate Coal Ore': 'coal',
              'Diamond Ore': 'diamond', 'Deepslate Diamond Ore': 'diamond'}


def drop(block, tool_id=None):
    """(id, count) the player gets for breaking *block* with *tool_id*, or None."""
    block = int(block)
    block = LOWER.get(block, block)          # the top of a door is the door
    block = _BASE.get(block, block)          # a door facing east is a door
    name = BLOCK_NAMES.get(block, '')
    if not can_harvest(block, tool_id):
        return None
    if name in _DROP_ITEM:
        return items.item_id(_DROP_ITEM[name]), 1
    if name in _DROP_AS:
        return _id(_DROP_AS[name]), 1
    if name in _DROP_NOTHING_NAMES or any(w in name for w in _DROP_NOTHING_WORDS):
        # Leaves now and then shake out a sapling, as they do in the real game.
        if 'Leaves' in name and random.random() < 0.08:
            sapling = _id(name.replace('Leaves', 'Sapling'))
            if sapling is not None:
                return sapling, 1
        return None
    if block in HIDDEN or block not in ICON_LAYER:
        return None
    return block, 1


# ---------------------------------------------------------------------------
# Inventory
# ---------------------------------------------------------------------------

class Inventory:
    """36 slots of `[block, count]` or None. Slots 0-8 are the hotbar."""

    def __init__(self, slots=None):
        self.slots = [None] * SLOTS
        if slots:
            for i, s in enumerate(slots[:SLOTS]):
                if s and (s[0] in ICON_LAYER or items.is_item(s[0])) and s[1] > 0:
                    self.slots[i] = [int(s[0]), int(s[1])]

    def to_list(self):
        return [list(s) if s else None for s in self.slots]

    def add(self, block, count=1):
        """Put *count* of *block* in; returns how many did not fit."""
        limit = items.stack_limit(block)
        for s in self.slots:                       # top up existing stacks
            if s and s[0] == block and s[1] < limit:
                take = min(count, limit - s[1])
                s[1] += take
                count -= take
                if not count:
                    return 0
        for i in range(SLOTS):                     # then the first empty slot
            if self.slots[i] is None:
                take = min(count, limit)
                self.slots[i] = [block, take]
                count -= take
                if not count:
                    return 0
        return count

    def block(self, slot):
        s = self.slots[slot]
        return s[0] if s else AIR

    def count(self, slot):
        s = self.slots[slot]
        return s[1] if s else 0

    def take_one(self, slot):
        s = self.slots[slot]
        if not s:
            return False
        s[1] -= 1
        if s[1] <= 0:
            self.slots[slot] = None
        return True

    def hotbar_ids(self):
        return [self.block(i) for i in range(HOTBAR)]


# ---------------------------------------------------------------------------
# Health and air
# ---------------------------------------------------------------------------

class Vitals:
    def __init__(self, health=MAX_HEALTH, air=MAX_AIR):
        self.health = health
        self.air = air
        self.since_hurt = REGEN_DELAY
        self.regen_clock = 0.0
        self.drown_clock = 0.0
        self.hurt_flash = 0.0           # seconds of red screen left

    @property
    def dead(self):
        return self.health <= 0

    def hurt(self, amount):
        if amount <= 0 or self.dead:
            return
        self.health = max(0, self.health - int(amount))
        self.since_hurt = 0.0
        self.hurt_flash = 0.35

    def update(self, dt, camera):
        """One frame of survival rules. Returns a cause of death or None."""
        if self.dead:
            return None
        cause = None

        fall = camera.landed_fall
        camera.landed_fall = 0.0
        if fall > SAFE_FALL:
            self.hurt(int(fall - SAFE_FALL + 0.5))
            cause = 'fall'

        if camera.head_in_water:
            self.air = max(0.0, self.air - dt)
            if self.air <= 0.0:
                self.drown_clock += dt
                if self.drown_clock >= 1.0:
                    self.drown_clock -= 1.0
                    self.hurt(2)
                    cause = 'drown'
        else:
            self.air = min(MAX_AIR, self.air + dt * 5.0)
            self.drown_clock = 0.0

        if camera.position.y < -32:           # below the world
            self.hurt(4)
            cause = 'void'

        self.since_hurt += dt
        self.hurt_flash = max(0.0, self.hurt_flash - dt)
        if self.since_hurt >= REGEN_DELAY and self.health < MAX_HEALTH:
            self.regen_clock += dt
            if self.regen_clock >= REGEN_STEP:
                self.regen_clock = 0.0
                self.health += 1

        return cause if self.dead else None
