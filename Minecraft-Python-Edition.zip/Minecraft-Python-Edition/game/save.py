"""Worlds on disk.

    saves/<folder>/level.json   name, seed, game mode, player, time, inventory
    saves/<folder>/chunks.npz   every chunk the player changed, compressed

Only *changed* chunks are written. Terrain is a pure function of the seed and
the chunk coordinates, so an untouched chunk regenerates exactly — storing it
would only make the save bigger. Both files are written to a temporary name and
then swapped in, so a crash halfway through a save leaves the previous one.
"""

import json
import os
import re
import shutil
import time

import numpy as np

from world.blocks import BLOCK_DTYPE

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAVES_DIR = os.path.join(ROOT, 'saves')
OPTIONS_PATH = os.path.join(ROOT, 'options.json')

DEFAULT_OPTIONS = {
    'render_distance': 8,
    'fov': 70,
    'sensitivity': 1.0,
    'daylight_cycle': True,
    'show_fps': False,
    'shadows': True,
    'mobs': True,
}


# ---------------------------------------------------------------------------
# options.json
# ---------------------------------------------------------------------------

def load_options():
    opts = dict(DEFAULT_OPTIONS)
    try:
        with open(OPTIONS_PATH, encoding='utf-8') as f:
            opts.update({k: v for k, v in json.load(f).items() if k in opts})
    except (OSError, ValueError):
        pass
    return opts


def save_options(opts):
    _write_json(OPTIONS_PATH, opts)


# ---------------------------------------------------------------------------
# Worlds
# ---------------------------------------------------------------------------

def _write_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def folder_name(name):
    """A folder for a new world: its name made filesystem-safe, numbered if
    taken — the real game's own rule, so two worlds can share a name."""
    base = re.sub(r'[\\/:*?"<>|.]+', '_', name).strip() or 'World'
    os.makedirs(SAVES_DIR, exist_ok=True)
    folder, n = base, 1
    while os.path.exists(os.path.join(SAVES_DIR, folder)):
        n += 1
        folder = f'{base} ({n})'
    return folder


def list_worlds():
    """Every readable world, most recently played first."""
    worlds = []
    if not os.path.isdir(SAVES_DIR):
        return worlds
    for folder in os.listdir(SAVES_DIR):
        path = os.path.join(SAVES_DIR, folder, 'level.json')
        try:
            with open(path, encoding='utf-8') as f:
                level = json.load(f)
        except (OSError, ValueError):
            continue
        level['folder'] = folder
        worlds.append(level)
    worlds.sort(key=lambda w: w.get('last_played', 0), reverse=True)
    return worlds


def delete_world(folder):
    shutil.rmtree(os.path.join(SAVES_DIR, folder), ignore_errors=True)


def new_level(name, seed, mode):
    return {
        'version': 1,
        'name': name,
        'seed': int(seed),
        'mode': mode,                # 'survival' or 'creative'
        'created': time.time(),
        'last_played': time.time(),
        'time_of_day': 1000,         # ticks, 0..24000, 1000 = morning
        'player': None,              # filled on first save
    }


def save_world(folder, level, chunks):
    """Write *level* (a dict) and *chunks* ({(cx, cz): blocks}) to disk."""
    path = os.path.join(SAVES_DIR, folder)
    os.makedirs(path, exist_ok=True)
    level['last_played'] = time.time()
    _write_json(os.path.join(path, 'level.json'), level)

    arrays = {f'c_{cx}_{cz}': np.asarray(blocks, dtype=BLOCK_DTYPE)
              for (cx, cz), blocks in chunks.items()}
    tmp = os.path.join(path, 'chunks.tmp.npz')
    np.savez_compressed(tmp, **arrays) if arrays else np.savez_compressed(tmp, empty=np.zeros(1))
    os.replace(tmp, os.path.join(path, 'chunks.npz'))


def load_world(folder):
    """(level, {(cx, cz): blocks}) for a saved world."""
    path = os.path.join(SAVES_DIR, folder)
    with open(os.path.join(path, 'level.json'), encoding='utf-8') as f:
        level = json.load(f)
    level['folder'] = folder

    chunks = {}
    npz_path = os.path.join(path, 'chunks.npz')
    if os.path.exists(npz_path):
        with np.load(npz_path) as data:
            for key in data.files:
                if not key.startswith('c_'):
                    continue
                _, cx, cz = key.split('_')
                chunks[(int(cx), int(cz))] = data[key].astype(BLOCK_DTYPE)
    return level, chunks
