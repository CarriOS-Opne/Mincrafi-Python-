"""Crafting and smelting — block-only recipes, because blocks are the only
items this game has. Recipes are written with block *names*, so they read like
the real game's, and matched shape-for-shape the way it matches them: the
pattern can sit anywhere in the grid, and a mirrored shape counts.
"""

from world.blocks import BLOCK_NAMES, HIDDEN
from game import items

_ID = {}
for _bid in sorted(BLOCK_NAMES):          # the pickable block, not a facing variant
    if _bid not in HIDDEN:
        _ID.setdefault(BLOCK_NAMES[_bid], _bid)
AIR = 0


def _id(name):
    return _ID.get(name)


def name(bid):
    return items.display_name(bid)


def is_planks(bid):
    return name(bid).endswith(' Planks')


def planks_for(bid):
    """The planks a log, stem or bark block saws into, or None."""
    n = name(bid).replace('Stripped ', '')
    for suffix in (' Log', ' Wood', ' Stem', ' Hyphae'):
        if n.endswith(suffix):
            return _id(n[:-len(suffix)] + ' Planks')
    return None


# ---------------------------------------------------------------------------
# Shaped recipes: rows of keys, a key -> test, and a result
# ---------------------------------------------------------------------------

def _is(block_name):
    target = _id(block_name)
    return lambda bid: bid == target


PLANKS = is_planks
COBBLE = _is('Cobblestone')


def _item(key):
    target = items.item_id(key)
    return lambda bid: bid == target


def _any(*names):
    ids = {_id(n) for n in names} - {None}
    return lambda bid: bid in ids


STICK = _item('stick')
STONE_TOOL = _any('Cobblestone', 'Cobbled Deepslate', 'Blackstone')
TOOL_MATERIALS = (('wooden', PLANKS), ('stone', STONE_TOOL),
                  ('copper', _item('copper_ingot')), ('iron', _item('iron_ingot')),
                  ('diamond', _item('diamond')))

SHAPED = [
    # (pattern, {key: test}, result name, count)
    (('##', '##'), {'#': PLANKS}, 'Crafting Table', 1),
    (('###', '# #', '###'), {'#': COBBLE}, 'Furnace', 1),
    (('##', '##'), {'#': _is('Stone')}, 'Stone Bricks', 4),
    (('##', '##'), {'#': _is('Sand')}, 'Sandstone', 1),
    (('##', '##'), {'#': _is('Red Sand')}, 'Red Sandstone', 1),
    (('##', '##'), {'#': _is('Andesite')}, 'Polished Andesite', 4),
    (('##', '##'), {'#': _is('Diorite')}, 'Polished Diorite', 4),
    (('##', '##'), {'#': _is('Granite')}, 'Polished Granite', 4),
    (('##', '##'), {'#': _is('Cobbled Deepslate')}, 'Polished Deepslate', 4),
    (('##', '##'), {'#': _is('Clay')}, 'Bricks', 1),
    (('##', '##'), {'#': _is('Packed Mud')}, 'Mud Bricks', 4),
    (('###', '###', '###'), {'#': _is('Wheat')}, 'Hay Bale', 1),
    (('###', 'ccc', '###'), {'#': PLANKS, 'c': _is('Oak Leaves')}, 'Bookshelf', 1),
    (('##', '##', '##'), {'#': PLANKS}, 'Oak Door', 3),
    (('# #', '###', '# #'), {'#': PLANKS}, 'Ladder', 3),
    (('#', '#'), {'#': PLANKS}, 'item:stick', 4),
    (('c', '|'), {'c': _item('coal'), '|': STICK}, 'Torch', 4),
    (('###', '#|#', '###'), {'#': _item('coal'), '|': STICK}, 'Block of Coal', 0),
    (('p', 't'), {'p': _is('Carved Pumpkin'), 't': _is('Torch')}, "Jack o'Lantern", 1),
    (('#',), {'#': _is('Pumpkin')}, 'Carved Pumpkin', 1),
]
# The real game's tool shapes, one per material.
for _mat, _test in TOOL_MATERIALS:
    SHAPED.append((('###', ' | ', ' | '), {'#': _test, '|': STICK}, f'item:{_mat}_pickaxe', 1))
    SHAPED.append((('#', '#', '|'), {'#': _test, '|': STICK}, f'item:{_mat}_sword', 1))


def _result_id(result):
    if result.startswith('item:'):
        return items.item_id(result[5:])
    return _id(result)


SHAPED = [r for r in SHAPED if r[3] > 0 and _result_id(r[2]) is not None]


def _trim(grid, size):
    """The grid's filled cells as a tight list of rows."""
    rows = [grid[r * size:(r + 1) * size] for r in range(size)]
    rows = [r for r in rows if any(r)]
    if not rows:
        return []
    cols = [c for c in range(size) if any(r[c] for r in rows)]
    return [r[cols[0]:cols[-1] + 1] for r in rows]


def _match(shape, pattern, keys):
    if len(shape) != len(pattern) or len(shape[0]) != len(pattern[0]):
        return False
    for row, prow in zip(shape, pattern):
        for bid, ch in zip(row, prow):
            if ch == ' ':
                if bid:
                    return False
            elif not bid or not keys[ch](bid):
                return False
    return True


def craft(grid, size):
    """(block id, count) the grid makes, or None. *grid* is size*size ids."""
    shape = _trim(list(grid), size)
    if not shape:
        return None

    # Shapeless: one log -> four planks of its wood.
    filled = [b for b in grid if b]
    if len(filled) == 1:
        planks = planks_for(filled[0])
        if planks is not None:
            return planks, 4

    for pattern, keys, result, count in SHAPED:
        for p in (pattern, tuple(r[::-1] for r in pattern)):
            if _match(shape, p, keys):
                return _result_id(result), count

    # Shapeless, by multiset of ingredients.
    bag = sorted(filled)
    scrap, gold = items.item_id('netherite_scrap'), items.item_id('gold_ingot')
    if bag == sorted([scrap] * 4 + [gold] * 4):
        return items.item_id('netherite_ingot'), 1
    # The smithing table's netherite upgrade, done on the crafting grid: a
    # diamond tool and a netherite ingot.
    ingot = items.item_id('netherite_ingot')
    if len(bag) == 2 and ingot in bag:
        other = bag[0] if bag[1] == ingot else bag[1]
        for kind in ('pickaxe', 'sword'):
            if other == items.item_id(f'diamond_{kind}'):
                return items.item_id(f'netherite_{kind}'), 1
    return None


# ---------------------------------------------------------------------------
# Smelting
# ---------------------------------------------------------------------------

SMELT = {
    'Sand': 'Glass', 'Red Sand': 'Glass', 'Cobblestone': 'Stone',
    'Stone': 'Smooth Stone', 'Clay': 'Terracotta', 'Cobbled Deepslate': 'Deepslate',
    'Stone Bricks': 'Cracked Stone Bricks', 'Sandstone': 'Smooth Sandstone',
    'Wet Sponge': 'Sponge', 'Netherrack': 'Nether Bricks',
}
SMELT = {_id(a): _id(b) for a, b in SMELT.items() if _id(a) and _id(b)}
for _ore, _ingot in (('Iron Ore', 'iron_ingot'), ('Deepslate Iron Ore', 'iron_ingot'),
                     ('Gold Ore', 'gold_ingot'), ('Deepslate Gold Ore', 'gold_ingot'),
                     ('Copper Ore', 'copper_ingot'), ('Deepslate Copper Ore', 'copper_ingot'),
                     ('Ancient Debris', 'netherite_scrap')):
    if _id(_ore):
        SMELT[_id(_ore)] = items.item_id(_ingot)
SMELT[items.item_id('porkchop')] = items.item_id('cooked_porkchop')
SMELT_TIME = 4.0          # seconds per item (the real game's 10 s, hurried)


def smelt_result(bid):
    return SMELT.get(int(bid)) if bid else None


def fuel_time(bid):
    """Seconds one *bid* burns for, or 0 if it is not fuel."""
    n = name(bid)
    if not n:
        return 0.0
    if n == 'Coal':
        return 80.0
    if n == 'Stick':
        return 5.0
    if 'Coal' in n:
        return 32.0
    if n.endswith(' Planks'):
        return 6.0
    if planks_for(bid):
        return 6.0
    if n in ('Crafting Table', 'Bookshelf', 'Ladder', 'Oak Door'):
        return 6.0
    if 'Sapling' in n or n == 'Dead Bush':
        return 2.0
    return 0.0
