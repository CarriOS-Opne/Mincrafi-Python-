"""Minecraft: Python Edition — entry point.

    App       the window, the menus, options, and which world is open
    Session   one world while it is open: camera, chunks, inventory, rules

The title screen is a Session too — a fixed-seed world the camera slowly turns
in, which is the real game's panorama done live instead of as six pictures.
"""

import math
import random
import os
import sys
import time

import pygame as pg
import glm

from engine.renderer import ModernGLRenderer
from engine.camera import Camera
from engine.hud import HUDRenderer, HOTBAR_SLOTS
from engine.overlay import Overlay
from engine.entities import Entities
from engine.drops import Drops
from engine import fonts
from world.modern_chunk import AIR, WATER
from world.blocks import (BLOCK_NAMES, COLLIDES, FACING, HOTBAR_DEFAULT, ICON_LAYER,
                          LOWER, UPPER, WALL_MOUNTED)
from world.threaded_chunk_manager import ThreadedChunkManager
from world import terrain_generator as tg
from world.terrain_generator import BIOME_NAMES, column_biome, find_spawn
from world.shapes import FACING_NAMES
from game import save, survival, crafting, items
from game.biomes import BiomeMap
from game import ui
from game.survival import Inventory, Vitals, MAX_HEALTH, MAX_AIR
import commands

try:                                   # the debug screen's memory and CPU lines
    import psutil
    _PROC, _RAM = psutil.Process(), psutil.virtual_memory
    _RAM_MB = _RAM().total >> 20
except ImportError:                    # not a game dependency; the lines just go
    _PROC = None

TITLE = 'Minecraft: Python Edition'

# What the crosshair goes straight through, and what a placed block overwrites.
REPLACEABLE = (AIR, WATER)

LOOK_AXIS = {'north': '-Z', 'east': '+X', 'south': '+Z', 'west': '-X'}
CONSOLE_KEYS = (pg.K_t, pg.K_SLASH, pg.K_KP_DIVIDE)

DAY_TICKS = 24000          # one day, in game ticks
TICKS_PER_SECOND = 20      # so a full day is 20 minutes, as in the real game
AUTOSAVE_SECONDS = 120
PANORAMA_SEED = 20261125

BREAK_REPEAT = 0.25        # creative: seconds between blocks while held
PLACE_REPEAT = 0.22


def look_direction(yaw):
    name = FACING_NAMES[(int(yaw % 360 + 45) // 90 + 1) % 4]
    return name, LOOK_AXIS[name]


def sun_for(ticks):
    """(daylight 0..1, unit vector to the sun) at a time of day. Tick 0 is
    sunrise in the east (+X), 6000 noon, 12000 sunset, 18000 midnight."""
    a = (ticks % DAY_TICKS) / DAY_TICKS * 2.0 * math.pi
    sun = glm.normalize(glm.vec3(math.cos(a), math.sin(a), 0.3))
    x = min(max((math.sin(a) + 0.12) / 0.38, 0.0), 1.0)
    return x * x * (3 - 2 * x), sun


def clock_name(ticks):
    t = ticks % DAY_TICKS
    if t < 500 or t > 23500:
        return '해돋이'
    if t < 11500:
        return '낮'
    if t < 13000:
        return '해질녘'
    return '밤'


# ===========================================================================
# Session — one open world
# ===========================================================================

class Session:
    CONSOLE_LINES = 8
    CONSOLE_LINGER = 8.0
    DEBUG_INTERVAL = 0.1

    def __init__(self, app, level, chunks, panorama=False):
        self.app = app
        self.renderer = app.renderer
        self.hud = app.hud
        self.level = level
        self.panorama = panorama
        tg.set_seed(level['seed'])

        spawn = level.get('spawn')
        if not spawn:
            spawn = list(find_spawn())
            level['spawn'] = spawn
        player = level.get('player') or {}

        pos = player.get('pos') or spawn
        if panorama:
            pos = (spawn[0], spawn[1] + 10, spawn[2])
        self.camera = Camera(position=pos, yaw=player.get('yaw', -90.0),
                             pitch=player.get('pitch', -5.0 if panorama else -20.0))
        self.camera.flying = bool(player.get('flying', panorama))

        self.render_distance = 6 if panorama else int(app.options['render_distance'])
        self.chunk_manager = ThreadedChunkManager(self.renderer, self.render_distance)
        self.chunk_manager.preload_modified(chunks)
        self.camera.set_world(self.chunk_manager)
        self.chunk_manager.pregenerate_spawn_chunks(self.camera.position.x,
                                                    self.camera.position.z)
        if not panorama and not player.get('pos'):
            level['spawn'] = self.settle(spawn)
            p = level['spawn']
            self.camera.position = glm.vec3(*p)
        cx, cz = self.chunk_manager.get_player_chunk(self.camera.position)
        for coords in self.chunk_manager.get_chunks_in_range(cx, cz):
            if coords not in self.chunk_manager.loaded_chunks:
                self.chunk_manager.request_chunk_load(*coords)

        # Rules
        self.mode = level.get('mode', 'creative')
        self.inventory = Inventory(player.get('inventory'))
        self.creative_hotbar = list(player.get('creative_hotbar') or HOTBAR_DEFAULT)
        self.vitals = Vitals(player.get('health', MAX_HEALTH), player.get('air', MAX_AIR))
        self.time_of_day = float(level.get('time_of_day', 1000))
        self.hotbar_slot = int(player.get('slot', 0))
        self.selected_block_type = AIR

        # Interaction state
        self.block_reach = 5.0 if self.mode == 'survival' else 8.0
        self.target = {'hit': False}
        self.mining_pos = None
        self.mining_progress = 0.0
        self.break_cooldown = 0.0
        self.place_cooldown = 0.0
        self.need_release = True       # ignore a button still held from a menu click
        self.autosave_clock = 0.0
        self.hide_hud = False
        self.toast = None              # (text, until)
        self.item_toast = None         # (text, until)

        # Debug + console (unchanged from the base engine)
        self.show_debug = False
        self.last_debug_update = 0.0
        self.last_cpu_sample = 0.0
        self.cpu_percent = 0.0
        self.rendered_chunks = self.total_chunks = 0
        self.frustum_culled = self.triangles = 0
        info = self.renderer.ctx.info
        self.gpu = (info['GL_RENDERER'], info['GL_VERSION'])
        self.inv_hover = -1
        self._swallow_text = False
        self.dragging_scrollbar = False
        self.console_open = False
        self.console_text = ''
        self.console_log = []
        self.console_history = []
        self.console_at = 0
        self.console_draft = ''

        self.entities = Entities(self.renderer, self.chunk_manager)
        self.drops = Drops(self.renderer, self.chunk_manager)
        self.biome_map = BiomeMap(self.renderer)
        self.biome_map.update(self.camera.position, block=True)
        self.day = int(level.get('day', 0))
        self.furnaces = {}
        for key, st in (level.get('furnaces') or {}).items():
            self.furnaces[tuple(int(v) for v in key.split(','))] = st
        self.attack_cooldown = 0.0
        self.last_space = 0.0
        self.last_w = 0.0
        self.sprint_lock = False

        self.hud.inventory_open = False
        self.set_mode(self.mode, announce=False)
        self._apply_daylight()

    # ------------------------------------------------------------------
    # Mode, hotbar, saving
    # ------------------------------------------------------------------

    @property
    def survival(self):
        return self.mode == 'survival'

    def set_mode(self, mode, announce=True):
        self.mode = self.level['mode'] = mode
        self.block_reach = 5.0 if self.survival else 8.0
        if self.survival:
            self.camera.flying = False
            if self.hud.inventory_open:
                self.toggle_inventory()
        self.sync_hotbar()
        if announce:
            self.say('게임 모드가 ' + ('서바이벌' if self.survival else '크리에이티브')
                     + ' 모드로 변경되었습니다')

    def sync_hotbar(self):
        ids = self.inventory.hotbar_ids() if self.survival else self.creative_hotbar
        for i, bid in enumerate(ids):
            self.hud.set_slot(i, bid)
        self.select_slot(self.hotbar_slot, quiet=True)

    def select_slot(self, slot, quiet=False):
        self.hotbar_slot = slot
        self.selected_block_type = self.hud.hotbar[slot]
        if not quiet and self.selected_block_type != AIR:
            self.item_toast = (items.display_name(self.selected_block_type), time.time() + 2.0)

    def say(self, message, seconds=3.0):
        self.toast = (message, time.time() + seconds)

    def player_state(self):
        c = self.camera
        return {
            'pos': [c.position.x, c.position.y, c.position.z],
            'yaw': c.yaw, 'pitch': c.pitch, 'flying': c.flying,
            'health': self.vitals.health, 'air': self.vitals.air,
            'inventory': self.inventory.to_list(),
            'creative_hotbar': [int(b) for b in self.creative_hotbar],
            'slot': self.hotbar_slot,
        }

    def save(self):
        if self.panorama:
            return
        self.level['player'] = self.player_state()
        self.level['time_of_day'] = self.time_of_day
        self.level['day'] = self.day
        self.level['furnaces'] = {f'{x},{y},{z}': st for (x, y, z), st in self.furnaces.items()}
        try:
            save.save_world(self.level['folder'], self.level,
                            self.chunk_manager.modified_chunks())
        except OSError as e:
            print(f'Save failed: {e}')
            self.say(f'저장 실패: {e}')

    def close(self):
        self.entities.release()
        self.drops.release()
        self.biome_map.release()
        self.chunk_manager.cleanup()

    def settle(self, pos):
        """An eye position at *pos*'s column with real room to stand.

        The spawn search reads the terrain *height*, which knows nothing of the
        trees, boulders and houses built on top of it — so a spawn can land
        inside a canopy. This walks up the generated column instead to the
        first two free cells over something solid."""
        x, z = int(math.floor(pos[0])), int(math.floor(pos[2]))
        get = self.chunk_manager.get_block_at
        start = max(1, int(tg.surface_height(x, z)) - 2)
        for y in range(start, 254):
            if COLLIDES[get(x, y - 1, z)] and not COLLIDES[get(x, y, z)] \
                    and not COLLIDES[get(x, y + 1, z)] and get(x, y, z) != WATER:
                return [x + 0.5, y + self.camera.player_height + 0.01, z + 0.5]
        return list(pos)

    def respawn(self):
        sx, sy, sz = self.level['spawn']
        self.vitals = Vitals()
        commands.teleport(self, sx, sz, sy)
        self.camera.fall_peak = None
        self.camera.landed_fall = 0.0

    # ------------------------------------------------------------------
    # Input
    # ------------------------------------------------------------------

    def handle_event(self, event):
        if self.panorama:
            return
        app = self.app
        if event.type == pg.TEXTINPUT and (self.console_open or self.hud.inventory_open):
            if self._swallow_text:
                self._swallow_text = False
            elif self.console_open:
                self.console_text += event.text
            else:
                self.hud.set_query(self.hud.query + event.text)
                self.inv_hover = self.hud.hit_test(*pg.mouse.get_pos())

        elif event.type == pg.KEYDOWN:
            if event.key == pg.K_F3:
                self.show_debug = not self.show_debug
            elif self.console_open:
                self.console_key(event.key)
            elif event.key == pg.K_ESCAPE:
                if self.hud.inventory_open:
                    self.toggle_inventory()
                else:
                    app.open(ui.PauseScreen(app))
            elif self.hud.inventory_open:
                if event.key == pg.K_BACKSPACE:
                    self.hud.set_query(self.hud.query[:-1])
                    self.inv_hover = self.hud.hit_test(*pg.mouse.get_pos())
            elif event.key == pg.K_e:
                if self.survival:
                    app.open(ui.InventoryScreen(app, self))
                else:
                    app.open(ui.CreativeScreen(app, self))
            elif (event.key in CONSOLE_KEYS
                  and not event.mod & (pg.KMOD_CTRL | pg.KMOD_ALT | pg.KMOD_GUI)):
                self.open_console('' if event.key == pg.K_t else '/')
            elif pg.K_1 <= event.key <= pg.K_1 + HOTBAR_SLOTS - 1:
                self.select_slot(event.key - pg.K_1)
            elif event.key in (pg.K_EQUALS, pg.K_KP_PLUS):
                self.step_render_distance(1)
            elif event.key in (pg.K_MINUS, pg.K_KP_MINUS):
                self.step_render_distance(-1)
            elif event.key == pg.K_f:
                self.chunk_manager.toggle_frustum_culling()
            elif event.key == pg.K_TAB:
                if self.survival:
                    self.say('서바이벌에서는 날 수 없어요  (/gamemode creative)')
                else:
                    self.camera.toggle_flying()
                    self.say('비행 ' + ('켬' if self.camera.flying else '끔'), 1.5)
            elif event.key == pg.K_SPACE:
                # Double-tap Space: take off / land, in creative — the real
                # game's way to fly. A single tap is still a jump.
                now = time.time()
                if not self.survival and now - self.last_space < 0.3:
                    self.camera.toggle_flying()
                    self.camera.velocity.y = 0.0
                    self.last_space = 0.0
                else:
                    self.last_space = now
                    if not self.camera.flying:
                        self.camera.jump()
            elif event.key == pg.K_w:
                # Double-tap W to sprint; it lasts until W is let go.
                now = time.time()
                if now - self.last_w < 0.3:
                    self.sprint_lock = True
                self.last_w = now
            elif event.key == pg.K_k:
                self.renderer.toggle_wireframe()
            elif event.key == pg.K_F1:
                self.hide_hud = not self.hide_hud
            elif event.key == pg.K_F2:
                self.app.screenshot_next = True
            app.refresh_mouse()

        elif event.type == pg.MOUSEBUTTONDOWN and not self.console_open:
            if self.hud.inventory_open:
                if event.button == 1:
                    self.click_picker(event.pos)
            elif event.button == 1:
                self.break_cooldown = 0.0
            elif event.button == 3:
                self.place_cooldown = 0.0
            elif event.button == 2:
                self.pick_block()

        elif event.type == pg.MOUSEBUTTONUP:
            self.dragging_scrollbar = False

        elif event.type == pg.MOUSEMOTION:
            if self.dragging_scrollbar:
                self.hud.scroll_to_mouse(event.pos[1])
                self.inv_hover = self.hud.hit_test(*event.pos)
            elif self.hud.inventory_open:
                self.inv_hover = self.hud.hit_test(*event.pos)
            elif app.mouse_captured:
                s = app.options['sensitivity'] * 0.3
                self.camera.process_mouse_movement(event.rel[0] * s, -event.rel[1] * s)

        elif event.type == pg.MOUSEWHEEL:
            if self.hud.inventory_open:
                self.hud.scroll_by(-event.y * self.hud.scroll_step)
                self.inv_hover = self.hud.hit_test(*pg.mouse.get_pos())
            elif not self.console_open:
                self.select_slot((self.hotbar_slot - event.y) % HOTBAR_SLOTS)

    def click_picker(self, pos):
        tab = self.hud.tab_at(*pos)
        if tab >= 0:
            self.hud.set_tab(tab)
            self.inv_hover = self.hud.hit_test(*pos)
            return
        if self.hud.scrollbar_at(*pos):
            self.dragging_scrollbar = True
            self.hud.scroll_to_mouse(pos[1])
            return
        slot = self.hud.hotbar_slot_at(*pos)
        if slot >= 0:
            self.select_slot(slot)
            return
        block_id = self.hud.block_at(self.hud.hit_test(*pos))
        if block_id is not None:
            self.creative_hotbar[self.hotbar_slot] = block_id
            self.hud.set_slot(self.hotbar_slot, block_id)
            self.selected_block_type = block_id

    def toggle_inventory(self):
        self.hud.inventory_open = not self.hud.inventory_open
        if self.hud.inventory_open:
            self._swallow_text = True
            self.app.refresh_mouse()
            pg.mouse.set_pos(self.renderer.width // 2, self.renderer.height // 2)
            self.inv_hover = self.hud.hit_test(*pg.mouse.get_pos())
        else:
            self.inv_hover = -1
            self.dragging_scrollbar = False
            self.hud.set_query('')
            self.need_release = True
            self.app.refresh_mouse()

    def pick_block(self):
        """Middle click: put the targeted block in the hand (creative)."""
        if self.survival:
            return
        hit = self.raycast()
        if not hit['hit']:
            return
        block = int(hit['block_type'])
        block = LOWER.get(block, block)
        for base, row in FACING.items():
            if block in row:
                block = base
                break
        if block in ICON_LAYER:
            self.creative_hotbar[self.hotbar_slot] = block
            self.hud.set_slot(self.hotbar_slot, block)
            self.select_slot(self.hotbar_slot)

    # ------------------------------------------------------------------
    # Console — see commands.py for the commands themselves
    # ------------------------------------------------------------------

    def step_render_distance(self, delta):
        value = min(max(self.render_distance + delta, commands.RENDER_MIN), commands.RENDER_MAX)
        commands.set_render_distance(self, value)
        self.app.options['render_distance'] = value
        self.say(f'렌더 거리: {value} 청크', 1.5)

    def open_console(self, prefill=''):
        self.console_open = True
        self.console_text = self.console_draft = prefill
        self.console_at = len(self.console_history)
        self._swallow_text = True
        self.app.refresh_mouse()

    def close_console(self):
        self.console_open = False
        self.console_text = ''
        self.need_release = True
        self.app.refresh_mouse()

    def console_key(self, key):
        if key in (pg.K_RETURN, pg.K_KP_ENTER):
            self.submit_console()
        elif key == pg.K_ESCAPE:
            self.close_console()
        elif key == pg.K_BACKSPACE:
            self.console_text = self.console_text[:-1]
        elif key == pg.K_UP:
            self.recall_console(-1)
        elif key == pg.K_DOWN:
            self.recall_console(1)

    def recall_console(self, delta):
        end = len(self.console_history)
        if delta < 0 and self.console_at == end:
            self.console_draft = self.console_text
        self.console_at = min(max(self.console_at + delta, 0), end)
        self.console_text = (self.console_draft if self.console_at == end
                             else self.console_history[self.console_at])

    def submit_console(self):
        text = self.console_text.strip()
        self.close_console()
        if not text:
            return
        if not self.console_history or self.console_history[-1] != text:
            self.console_history.append(text)
        now = time.perf_counter()
        if not text.startswith('/'):
            # Plain text is chat, as in the real game: it just goes in the log.
            self.console_log.append((f'<플레이어> {text}', (255, 255, 255), now))
        else:
            self.console_log += [(line, color, now)
                                 for line, color in commands.dispatch(self, text)]
        del self.console_log[:-self.CONSOLE_LINES]

    def update_console(self):
        cutoff = time.perf_counter() - self.CONSOLE_LINGER
        lines = [(text, color) for text, color, when in self.console_log
                 if self.console_open or when > cutoff]
        self.hud.set_console(
            lines[-self.CONSOLE_LINES:],
            '> ' + self.console_text + '|' if self.console_open else None)

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def process_keyboard(self, dt):
        keys = pg.key.get_pressed()
        cam = self.camera
        cam.strafe = [0, 0]
        cam.swim_up = False
        if self.hud.inventory_open or self.console_open or self.app.screen is not None:
            cam.sprinting = False
            return
        # Sprint: Ctrl held, or W double-tapped (held W keeps it going).
        if not keys[pg.K_w]:
            self.sprint_lock = False
        sneak = (keys[pg.K_LSHIFT] or keys[pg.K_RSHIFT]) and not cam.flying
        cam.sprinting = (keys[pg.K_LCTRL] or self.sprint_lock) and keys[pg.K_w] and not sneak
        cam.sneaking = sneak
        if keys[pg.K_w]:
            cam.strafe[0] += 1.0
        if keys[pg.K_s]:
            cam.strafe[0] -= 1.0
        if keys[pg.K_a]:
            cam.strafe[1] -= 1.0
        if keys[pg.K_d]:
            cam.strafe[1] += 1.0
        cam.swim_up = keys[pg.K_SPACE]
        if cam.flying:
            # Vertical flight goes through the velocity, so the ground stops
            # it — and touching down ends the flight, as in the game.
            v = 7.5 * (2.0 if cam.sprinting else 1.0)
            cam.fly_vertical = (v if keys[pg.K_SPACE] else 0.0) - (v if keys[pg.K_LSHIFT] else 0.0)
        elif keys[pg.K_SPACE] and cam.on_ground and not cam.in_water:
            cam.jump()            # hold Space to keep hopping, as in the game

    def update(self, dt, paused):
        if self.panorama:
            self.camera.yaw += dt * 2.5
            self.camera.update_camera_vectors()
            self.chunk_manager.update(self.camera.position)
            self.time_of_day = 2500
            self._apply_daylight()
            self.entities.update(dt, self.camera.position, self.biome_name,
                                 spawn=self.app.options['mobs'])
            return

        if paused:
            self.camera.strafe = [0, 0]
            self.chunk_manager.update(self.camera.position)
            self.update_console()
            return

        self.process_keyboard(dt)
        steps = 8
        for _ in range(steps):
            self.camera.update_physics(dt / steps)
        self.chunk_manager.update(self.camera.position)

        if self.app.options['daylight_cycle']:
            t = self.time_of_day + dt * TICKS_PER_SECOND
            if t >= DAY_TICKS:
                self.day += 1
            self.time_of_day = t % DAY_TICKS
        self._apply_daylight()

        if self.app.options['mobs']:
            self.entities.update(dt, self.camera.position, self.biome_name)
        elif self.entities.mobs:
            self.entities.mobs = []
        self.tick_furnaces(dt)

        self.update_hands(dt)
        if self.drops.update(dt, self.camera.position, self.inventory, self.survival):
            self.sync_hotbar()

        if self.survival:
            cause = self.vitals.update(dt, self.camera)
            if cause:
                self.app.on_death(cause)

        self.autosave_clock += dt
        if self.autosave_clock >= AUTOSAVE_SECONDS:
            self.autosave_clock = 0.0
            self.save()

        self.update_debug()
        self.update_console()

    def _apply_daylight(self):
        daylight, sun = sun_for(self.time_of_day)
        self.renderer.set_daylight(daylight, sun)
        self.renderer.set_moon_phase(self.day)
        self.sun = sun

    def biome_name(self, x, z):
        return BIOME_NAMES[column_biome(x, z)]

    # ------------------------------------------------------------------
    # Furnaces
    # ------------------------------------------------------------------

    @staticmethod
    def new_furnace():
        return {'in': None, 'fuel': None, 'out': None, 'burn': 0.0, 'burn_max': 0.0, 'cook': 0.0}

    def tick_furnaces(self, dt):
        for st in self.furnaces.values():
            src = st['in']
            result = crafting.smelt_result(src[0]) if src else None
            out = st['out']
            can = result is not None and (out is None or (out[0] == result and out[1] < 64))
            if st['burn'] <= 0 and can and st['fuel']:
                t = crafting.fuel_time(st['fuel'][0])
                if t > 0:
                    st['burn'] = st['burn_max'] = t
                    st['fuel'][1] -= 1
                    if st['fuel'][1] <= 0:
                        st['fuel'] = None
            if st['burn'] > 0:
                st['burn'] = max(0.0, st['burn'] - dt)
                if can:
                    st['cook'] += dt
                    if st['cook'] >= crafting.SMELT_TIME:
                        st['cook'] = 0.0
                        src[1] -= 1
                        if src[1] <= 0:
                            st['in'] = None
                        if out:
                            out[1] += 1
                        else:
                            st['out'] = [result, 1]
                else:
                    st['cook'] = 0.0
            else:
                st['cook'] = max(0.0, st['cook'] - dt * 2)

    def use_block(self):
        """Right click on a crafting table or furnace opens it (survival)."""
        if not self.survival:
            return False
        hit = self.raycast()
        if not hit['hit']:
            return False
        name = BLOCK_NAMES.get(int(hit['block_type']), '')
        if name == 'Crafting Table':
            self.app.open(ui.CraftingTableScreen(self.app, self))
            return True
        if name.startswith('Furnace') or name == 'Smoker' or name == 'Blast Furnace':
            key = tuple(hit['block_pos'])
            st = self.furnaces.setdefault(key, self.new_furnace())
            self.app.open(ui.FurnaceScreen(self.app, self, st))
            return True
        return False

    def update_hands(self, dt):
        """Held buttons: break (timed in survival) and place, repeating."""
        captured = self.app.mouse_captured
        left, middle, right = pg.mouse.get_pressed()[:3] if captured else (False,) * 3
        if self.need_release:
            if left or right:
                left = right = False
            else:
                self.need_release = False

        self.break_cooldown -= dt
        self.place_cooldown -= dt

        self.attack_cooldown -= dt
        if left and self.attack_cooldown <= 0:
            cam = self.camera
            mob = self.entities.raycast(cam.position, cam.front, 4.0 if self.survival else 6.0)
            if mob is not None:
                block = self.raycast()
                bd = (glm.length(glm.vec3(block['block_pos']) + 0.5 - cam.position)
                      if block['hit'] else 1e9)
                if mob[1] < bd:
                    held = items.get(self.selected_block_type) if items.is_item(self.selected_block_type) else None
                    damage = held.damage if held and held.kind in ('sword', 'pickaxe') else 1
                    target = mob[0]
                    self.entities.hit(target, cam.front, damage)
                    if target.dead and self.survival and target.kind == 'pig':
                        self.drops.spawn(items.item_id('porkchop'), random.randint(1, 3),
                                         target.pos.x, target.pos.y + 0.5, target.pos.z)
                    self.attack_cooldown = 0.45
                    self.break_cooldown = 0.3
                    left = False
        if left:
            hit = self.raycast()
            if not hit['hit']:
                self.mining_pos, self.mining_progress = None, 0.0
            elif self.survival:
                pos = hit['block_pos']
                if pos != self.mining_pos:
                    self.mining_pos, self.mining_progress = pos, 0.0
                bt = survival.break_time(hit['block_type'], self.selected_block_type)
                if bt is not None and self.break_cooldown <= 0:
                    self.mining_progress += dt / max(bt, 1e-3)
                    if self.mining_progress >= 1.0:
                        self.remove_block(hit)
                        self.mining_pos, self.mining_progress = None, 0.0
                        self.break_cooldown = 0.15
            elif self.break_cooldown <= 0:
                self.remove_block(hit)
                self.break_cooldown = BREAK_REPEAT
        else:
            self.mining_pos, self.mining_progress = None, 0.0

        if right and self.place_cooldown <= 0:
            if self.use_block():
                self.need_release = True
            else:
                self.add_block()
            self.place_cooldown = PLACE_REPEAT

    def update_debug(self):
        now = time.perf_counter()
        if not self.show_debug or now - self.last_debug_update < self.DEBUG_INTERVAL:
            return
        self.last_debug_update = now

        cam = self.camera
        pos = cam.position
        bx, by, bz = (int(math.floor(v)) for v in (pos.x, pos.y, pos.z))
        cx, cz = self.chunk_manager.world_to_chunk_coords(pos.x, pos.z)
        info = self.chunk_manager.get_chunk_info()
        look, axis = look_direction(cam.yaw)
        mode = 'Flying' if cam.flying else ('Swimming' if cam.in_water else
                                            'Walking' if cam.on_ground else 'In air')
        if cam.sprinting:
            mode += ', sprinting'

        left = (
            f'{TITLE} ({self.mode})',
            f'{self.app.clock.get_fps():.0f} fps',
            f'C: {self.rendered_chunks}/{self.total_chunks}   '
            f'F: {self.frustum_culled}   T: {self.triangles / 1000:.0f}k tri',
            f"L: {info['loaded_chunks']}   P: {info['pending_chunks']}   "
            f"Cache: {info['cached_chunks']}   LOD: {'/'.join(str(n) for n in info['lod_counts'])}",
            f"RD: {self.render_distance}   seed: {self.level['seed']}",
            '',
            f'XYZ: {pos.x:.3f} / {pos.y:.3f} / {pos.z:.3f}',
            f'Block: {bx} {by} {bz}',
            f'Chunk: {bx - cx * 16} {by} {bz - cz * 16} in {cx} {cz}',
            f'Facing: {look} (towards {axis})   ({cam.yaw % 360:.1f} / {cam.pitch:.1f})',
            f'Biome: {BIOME_NAMES[column_biome(bx, bz)]}',
            f'Day time: {int(self.time_of_day)} ticks',
            f'{mode}   {math.hypot(cam.velocity.x, cam.velocity.z):.1f} m/s',
            f'Held: {items.display_name(self.selected_block_type, "Empty")}',
        )
        right = [f'Python {sys.version.split()[0]}   pygame {pg.version.ver}']
        if _PROC is not None:
            if now - self.last_cpu_sample >= 1.0:
                self.last_cpu_sample = now
                self.cpu_percent = _PROC.cpu_percent()
            right.append(f'Mem: {_PROC.memory_info().rss >> 20} MB   '
                         f'CPU: {self.cpu_percent:.0f}% of one core')
            right.append(f'RAM: {_RAM().percent:.0f}% of {_RAM_MB} MB')
        right += [f'Display: {self.renderer.width}x{self.renderer.height}',
                  self.gpu[0], f'GL {self.gpu[1]}', '']
        if self.target['hit']:
            block = int(self.target['block_type'])
            right += ['Targeted Block: {} {} {}'.format(*self.target['block_pos']),
                      f'{BLOCK_NAMES.get(block, "Unknown")} (id {block})']
        else:
            right.append('Targeted Block: none')
        self.hud.set_debug(left, tuple(right))

    # ------------------------------------------------------------------
    # Render
    # ------------------------------------------------------------------

    def render_world(self):
        r = self.renderer
        r.clear()
        if r.block_texture:
            r.bind_texture(r.block_texture)
        view = self.camera.get_view_matrix()
        sun = getattr(self, 'sun', glm.vec3(0, 1, 0))
        strength = 0.0
        if self.app.options['shadows'] and sun.y > 0.0:
            strength = min(1.0, max(0.0, (sun.y - 0.03) / 0.22))
        r.render_shadow_map(self.chunk_manager.chunks.values(), self.camera.position, sun, strength)
        self.biome_map.update(self.camera.position)
        self.biome_map.bind()
        r.update_matrices(view, glm.mat4(1.0))
        t = time.time() - self.app.start_time
        r.render_sky(view, t)
        (self.rendered_chunks, self.total_chunks, self.frustum_culled,
         self.triangles) = self.chunk_manager.render_chunks(view, r.proj_matrix)
        self.entities.render(view, r.proj_matrix, self.camera.position,
                             r.fog_start, r.fog_end, t)
        self.drops.render(view, r.proj_matrix, self.camera.position,
                          r.fog_start, r.fog_end, t)
        r.render_water_surface(view, self.camera.position)
        if self.panorama:
            return
        self.target = self.raycast()
        if self.target['hit'] and not self.hide_hud:
            r.render_block_outline(self.target['block_pos'], view, r.proj_matrix)

    def render_tints(self, overlay):
        if self.panorama:
            return
        if self.camera.head_in_water:
            overlay.tint((20, 50, 150, 95))
        if self.vitals.hurt_flash > 0:
            overlay.tint((190, 0, 0, int(110 * self.vitals.hurt_flash / 0.35)))

    def render_hud(self, overlay):
        """Crosshair, hotbar, and the pygame-drawn survival HUD on top."""
        if self.panorama or self.hide_hud:
            return
        self.renderer.render_crosshair()

        now = time.time()
        toast = self.toast if self.toast and self.toast[1] > now else None
        item = self.item_toast if self.item_toast and self.item_toast[1] > now else None
        fps = int(self.app.clock.get_fps()) if self.app.options['show_fps'] else None
        bubbles = math.ceil(self.vitals.air / MAX_AIR * 10) if self.vitals.air < MAX_AIR else None
        key = (self.renderer.width, self.renderer.height, self.mode, self.vitals.health,
               bubbles, self.hotbar_slot, tuple(self.hud.hotbar),
               tuple(self.inventory.count(i) for i in range(9)) if self.survival else None,
               int(self.mining_progress * 20), toast and toast[0],
               item and (item[0], int(min(1.0, item[1] - now) * 8)),
               fps if not self.show_debug else None, self.hud.inventory_open)
        if overlay.needs(key):
            self.draw_hud(overlay.surface, toast, item, fps, bubbles)
        overlay.draw()

        self.hud.render_console()
        if self.show_debug:
            self.hud.render_debug()

    def draw_hud(self, surf, toast, item, fps, bubbles):
        """The hotbar, hearts and air in the real game's layout and GUI scale."""
        w, h = surf.get_size()
        g = ui.gui_scale(w, h)
        x0 = w // 2 - 91 * g
        y0 = h - 22 * g

        # hotbar: a dark strip of 9 grey-framed slots, the selected one boxed
        bar = pg.Rect(x0, y0, 182 * g, 22 * g)
        surf.fill((0, 0, 0, 255), bar)
        surf.fill((48, 48, 48, 200), bar.inflate(-2 * g, -2 * g))
        for i in range(9):
            cell = pg.Rect(x0 + (1 + 20 * i) * g, y0 + g, 20 * g, 20 * g)
            pg.draw.rect(surf, (139, 139, 139, 255), cell, g)
        sel = pg.Rect(x0 + (20 * self.hotbar_slot - 1) * g, y0 - g, 24 * g, 24 * g)
        pg.draw.rect(surf, (0, 0, 0, 255), sel, g)
        pg.draw.rect(surf, (235, 235, 235, 255), sel.inflate(-2 * g, -2 * g), 2 * g)
        for i, bid in enumerate(self.hud.hotbar):
            if not bid:
                continue
            stack = [bid, self.inventory.count(i) if self.survival else 1]
            ui.draw_stack(surf, self.app.icons, stack, x0 + (3 + 20 * i) * g,
                          y0 + 3 * g, 16 * g, g)

        if self.survival:
            hy = y0 - 10 * g
            for i in range(10):
                full = self.vitals.health - 2 * i
                ui.heart(surf, x0 + i * 8 * g, hy, g, 2 if full >= 2 else 1 if full == 1 else 0)
            if bubbles is not None:
                for i in range(bubbles):
                    ui.bubble(surf, x0 + 182 * g - (i + 1) * 8 * g, hy, g)

        if self.mining_progress > 0:
            bw, bh = 30 * g, 3 * g
            x, y = w // 2 - bw // 2, h // 2 + 10 * g
            surf.fill((0, 0, 0, 160), (x - g, y - g, bw + 2 * g, bh + 2 * g))
            surf.fill((255, 255, 255, 230), (x, y, int(bw * min(1.0, self.mining_progress)), bh))

        fs = ui.font_px(g)
        if item:
            alpha = int(255 * min(1.0, item[1] - time.time()))
            ui.text(surf, item[0], fs, center=(w // 2, y0 - (24 if self.survival else 12) * g),
                    alpha=max(0, alpha))
        if toast:
            ui.text(surf, toast[0], fs, (255, 255, 120), center=(w // 2, int(h * 0.68)))
        if fps is not None and not self.show_debug:
            ui.text(surf, f'{fps} FPS', fs, topleft=(4 * g, 4 * g))

    # ------------------------------------------------------------------
    # Blocks
    # ------------------------------------------------------------------

    def raycast(self):
        """3D DDA from the eye along the view direction."""
        origin = self.camera.position
        direction = self.camera.front
        max_distance = self.block_reach
        x, y, z = (int(math.floor(v)) for v in (origin.x, origin.y, origin.z))
        step = [1 if d > 0 else (-1 if d < 0 else 0) for d in (direction.x, direction.y, direction.z)]

        def t_max(p, d, s):
            if d == 0:
                return float('inf')
            boundary = math.floor(p) + (1.0 if s > 0 else 0.0)
            if s < 0 and p == boundary:
                boundary -= 1.0
            return (boundary - p) / d

        tx = t_max(origin.x, direction.x, step[0])
        ty = t_max(origin.y, direction.y, step[1])
        tz = t_max(origin.z, direction.z, step[2])
        dx = abs(1.0 / direction.x) if direction.x else float('inf')
        dy = abs(1.0 / direction.y) if direction.y else float('inf')
        dz = abs(1.0 / direction.z) if direction.z else float('inf')
        px, py, pz = x, y, z
        while True:
            block = self.chunk_manager.get_block_at(x, y, z)
            if block not in REPLACEABLE:
                return {'hit': True, 'block_pos': (x, y, z),
                        'prev_pos': (px, py, pz), 'block_type': block}
            px, py, pz = x, y, z
            if tx < ty and tx < tz:
                if tx > max_distance:
                    break
                x += step[0]
                tx += dx
            elif ty < tz:
                if ty > max_distance:
                    break
                y += step[1]
                ty += dy
            else:
                if tz > max_distance:
                    break
                z += step[2]
                tz += dz
        return {'hit': False}

    def get_block_at(self, x, y, z):
        return self.chunk_manager.get_block_at(x, y, z)

    def set_block_at(self, x, y, z, block_type):
        return self.chunk_manager.set_block_at(x, y, z, block_type)

    def remove_block(self, hit=None):
        hit = hit or self.raycast()
        if not hit['hit']:
            return
        x, y, z = hit['block_pos']
        block = int(hit['block_type'])
        if self.survival and survival.break_time(block, self.selected_block_type) is None:
            return
        self.set_block_at(x, y, z, AIR)
        if block in UPPER:
            self.set_block_at(x, y + 1, z, AIR)
        elif block in LOWER:
            self.set_block_at(x, y - 1, z, AIR)
        st = self.furnaces.pop((x, y, z), None)
        if st and self.survival:
            for k in ('in', 'fuel', 'out'):
                if st[k]:
                    self.drops.spawn(st[k][0], st[k][1], x + 0.5, y + 0.4, z + 0.5)
        if self.survival:
            got = survival.drop(block, self.selected_block_type)
            if got and got[0] is not None:
                self.drops.spawn(got[0], got[1], x + 0.5, y + 0.3, z + 0.5)

    def orient(self, block_id, cell, target):
        row = FACING.get(block_id)
        if row is None:
            return block_id
        dx = target[0] - cell[0]
        dz = target[2] - cell[2]
        if block_id not in WALL_MOUNTED or (dx == 0 and dz == 0):
            yaw = math.radians(self.camera.yaw)
            dx, dz = -math.cos(yaw), -math.sin(yaw)
        if abs(dx) > abs(dz):
            return row[1] if dx > 0 else row[3]
        return row[2] if dz > 0 else row[0]

    def add_block(self):
        held = self.selected_block_type
        if items.is_item(held):
            it = items.get(held)
            if it and it.kind == 'food' and self.survival and self.vitals.health < MAX_HEALTH:
                self.vitals.health = min(MAX_HEALTH, self.vitals.health + it.heal)
                self.inventory.take_one(self.hotbar_slot)
                self.sync_hotbar()
                self.place_cooldown = 1.2         # one bite at a time
                self.say(f'{it.name} 먹음 (+{it.heal / 2:g}칸)', 1.5)
            return False
        hit = self.raycast()
        if not hit['hit'] or held == AIR:
            return False
        x, y, z = hit['prev_pos']
        if self.get_block_at(x, y, z) not in REPLACEABLE:
            return False
        block_id = self.orient(self.selected_block_type, hit['prev_pos'], hit['block_pos'])
        if COLLIDES[block_id] and self.camera.intersects_block(x, y, z):
            return False
        upper = UPPER.get(block_id)
        if upper is not None:
            if (self.get_block_at(x, y + 1, z) not in REPLACEABLE
                    or (COLLIDES[block_id] and self.camera.intersects_block(x, y + 1, z))):
                return False
            self.set_block_at(x, y + 1, z, upper)
        self.set_block_at(x, y, z, block_id)
        if self.survival:
            self.inventory.take_one(self.hotbar_slot)
            self.sync_hotbar()
        return True


# ===========================================================================
# App — window, menus, options
# ===========================================================================

class App:
    def __init__(self, width=1280, height=800):
        self.renderer = ModernGLRenderer(width, height)
        pg.display.set_caption(TITLE)
        self.renderer.load_textures()
        self.hud = HUDRenderer(self.renderer.ctx, width, height)
        self.overlay_hud = Overlay(self.renderer.ctx, width, height)
        self.overlay_ui = Overlay(self.renderer.ctx, width, height)
        self.icons = ui.Icons('texture.png')
        self.options = save.load_options()
        self.clock = pg.time.Clock()
        self.start_time = time.time()
        self.running = True
        self.session = None
        self.screen = None
        self.mouse_captured = False
        self.screenshot_next = False
        self.apply_options()
        self.go_to_title()

    # -- sizes ------------------------------------------------------------
    @property
    def width(self):
        return self.renderer.width

    @property
    def height(self):
        return self.renderer.height

    def resize(self, w, h):
        self.renderer.resize(w, h)
        self.hud.resize(w, h)
        self.overlay_hud.resize(w, h)
        self.overlay_ui.resize(w, h)
        if self.screen:
            self.screen.layout(w, h)

    # -- mouse ------------------------------------------------------------
    def refresh_mouse(self):
        s = self.session
        want = (s is not None and not s.panorama and self.screen is None
                and not s.console_open and not self.hud.inventory_open)
        if want != self.mouse_captured:
            self.mouse_captured = want
            pg.mouse.set_visible(not want)
            pg.event.set_grab(want)
            pg.mouse.get_rel()                 # drop the jump the grab causes

    # -- screens ----------------------------------------------------------
    def open(self, screen):
        self.screen = screen
        screen.layout(self.width, self.height)
        self.refresh_mouse()

    def close_screen(self):
        self.screen = None
        if self.session:
            self.session.need_release = True
        self.refresh_mouse()

    def show_loading(self, title, sub=''):
        """Draw one frame of a loading screen before blocking work."""
        pg.event.pump()
        self.renderer.ctx.clear(0.0, 0.0, 0.0)
        o = self.overlay_ui
        o.needs(object())
        ui.LoadingScreen(self, title, sub).draw(o.surface, (0, 0))
        o.draw()
        pg.display.flip()

    # -- worlds -----------------------------------------------------------
    def _end_session(self):
        if self.session:
            self.session.save()
            self.session.close()
            self.session = None
        self.hud.inventory_open = False

    def go_to_title(self):
        self.show_loading('세계를 불러오는 중...', '처음 실행할 때는 조금 오래 걸려요')
        self._end_session()
        level = save.new_level('panorama', PANORAMA_SEED, 'creative')
        self.session = Session(self, level, {}, panorama=True)
        self.open(ui.TitleScreen(self))

    def leave_world(self):
        self.show_loading('월드를 저장하는 중...')
        self.go_to_title()

    def start_world(self, folder):
        self.show_loading('월드를 불러오는 중...', '지형 생성 중')
        self._end_session()
        try:
            level, chunks = save.load_world(folder)
        except (OSError, ValueError) as e:
            print(f'Could not load {folder}: {e}')
            self.go_to_title()
            return
        self.session = Session(self, level, chunks)
        self.screen = None
        self.refresh_mouse()
        self.session.say(f"'{level['name']}'에 오신 것을 환영합니다!")

    def create_world(self, name, seed_text, mode):
        seed = tg.seed_to_int(seed_text)
        folder = save.folder_name(name)
        self.show_loading('새로운 월드를 만드는 중...', '지형 생성 중')
        self._end_session()
        level = save.new_level(name, seed, mode)
        level['folder'] = folder
        self.session = Session(self, level, {})
        self.session.save()
        self.screen = None
        self.refresh_mouse()
        self.session.say(f"'{name}'에 오신 것을 환영합니다!")

    def respawn(self):
        if self.session:
            self.session.respawn()
        self.close_screen()

    def on_death(self, cause):
        self.open(ui.DeathScreen(self, cause))

    def quit(self):
        self.running = False

    # -- options ----------------------------------------------------------
    def apply_options(self):
        o = self.options
        if abs(self.renderer.fov - o['fov']) > 0.01:
            self.renderer.set_fov(o['fov'])
        s = self.session
        if s and not s.panorama and s.render_distance != int(o['render_distance']):
            commands.set_render_distance(s, int(o['render_distance']))

    def save_options(self):
        save.save_options(self.options)

    # -- loop -------------------------------------------------------------
    def handle_events(self):
        for e in pg.event.get():
            if e.type == pg.QUIT:
                self.quit()
            elif e.type == pg.VIDEORESIZE:
                self.resize(max(e.w, 320), max(e.h, 240))
            elif e.type == pg.WINDOWFOCUSLOST:
                s = self.session
                if s and not s.panorama and self.screen is None and not s.console_open:
                    self.open(ui.PauseScreen(self))
            elif self.screen is not None:
                self.screen.event(e)
            elif self.session:
                self.session.handle_event(e)

    def render(self):
        s = self.session
        if s:
            s.render_world()
            s.render_tints(self.overlay_hud)
            if not isinstance(self.screen, ui.DeathScreen):
                s.render_hud(self.overlay_hud)
        else:
            self.renderer.ctx.clear(0.0, 0.0, 0.0)
        if self.screen is not None:
            o = self.overlay_ui
            o.needs(object())        # menus redraw every frame: hover, caret, splash
            self.screen.draw(o.surface, pg.mouse.get_pos())
            o.draw()
        if self.screenshot_next:
            self.screenshot_next = False
            self.take_screenshot()
        pg.display.flip()

    def take_screenshot(self):
        data = self.renderer.ctx.screen.read(components=3)
        os.makedirs('screenshots', exist_ok=True)
        name = time.strftime('screenshots/%Y-%m-%d_%H.%M.%S.png')
        img = pg.image.frombuffer(data, (self.width, self.height), 'RGB')
        pg.image.save(pg.transform.flip(img, False, True), name)
        if self.session:
            self.session.say(f'스크린샷 저장: {name}')

    def step(self, dt):
        self.handle_events()
        if not self.running:
            return
        if self.session:
            paused = self.screen is not None and self.screen.pauses
            self.session.update(dt, paused)
        self.render()

    def run(self):
        last = time.perf_counter()
        while self.running:
            now = time.perf_counter()
            dt = min(now - last, 0.2)
            last = now
            self.step(dt)
            self.clock.tick(144)
        self.shutdown()

    def shutdown(self):
        self._end_session()
        self.save_options()
        pg.quit()


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    try:
        import moderngl, numpy, numba  # noqa: F401
    except ImportError as e:
        print(f'필요한 패키지가 없습니다: {e}')
        print('pip install -r requirements.txt 를 실행하세요.')
        sys.exit(1)
    App().run()


if __name__ == '__main__':
    main()
