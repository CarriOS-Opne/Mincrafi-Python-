#version 330 core
layout (location = 0) in vec3 in_position;
layout (location = 2) in vec2 in_uv;
layout (location = 3) in float in_face;

uniform mat4 m_proj;
uniform mat4 m_view;
uniform mat4 m_model;

out vec2 uv;
flat out int face;
out vec3 frag_world_pos;

void main() {
    vec4 world = m_model * vec4(in_position, 1.0);
    frag_world_pos = world.xyz;
    uv = in_uv;
    face = int(in_face + 0.5);
    gl_Position = m_proj * m_view * world;
}
