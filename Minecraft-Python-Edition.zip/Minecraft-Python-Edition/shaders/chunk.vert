#version 330 core

layout (location = 0) in vec3 in_position;
layout (location = 1) in vec3 in_tex_coord;
layout (location = 2) in float in_shading;

uniform mat4 m_proj;
uniform mat4 m_view;
uniform mat4 m_model;  // Keep for Python compatibility (always identity)

out vec3 uv;
out float shading;
flat out int tint_class;     // 0 none, 1 grass, 2 foliage, 3 grass-block side
out vec3 frag_world_pos;

void main() {
    // OPTIMIZATION: Direct position assignment (m_model is always identity)
    // We keep the uniform declared to avoid Python errors
    frag_world_pos = in_position;
    
    // Pass texture coordinates and shading
    // The mesher packs the biome-tint class into the layer: layer + 4096 * class.
    float cls = floor(in_tex_coord.z / 4096.0);
    tint_class = int(cls);
    uv = vec3(in_tex_coord.xy, in_tex_coord.z - cls * 4096.0);
    shading = in_shading;
    
    // Calculate final position (also optimized - skip m_model)
    gl_Position = m_proj * m_view * vec4(in_position, 1.0);
}
