#version 330 core
layout (location = 0) in vec3 in_position;   // model pixels, Minecraft model space
layout (location = 1) in vec2 in_uv;
layout (location = 2) in float in_shade;

uniform mat4 m_proj;
uniform mat4 m_view;
uniform mat4 m_model;

out vec2 uv;
out float shade;
out vec3 frag_world_pos;

void main() {
    vec4 world = m_model * vec4(in_position, 1.0);
    frag_world_pos = world.xyz;
    uv = in_uv;
    shade = in_shade;
    gl_Position = m_proj * m_view * world;
}
