#version 330 core
#include "sky_common.glsl"

out vec4 fragColor;
in vec3 frag_pos;

uniform mat4 m_inv_pv; // Inverse Projection * View matrix to rebuild the ray
uniform sampler2D u_sun_tex;    // assets/sky/sun.png, glow included
uniform sampler2D u_moon_tex;   // assets/sky/moon_phases.png, 8 phases side by side
uniform float u_moon_phase;     // 0..7

// The sun and the moon are textured squares added onto the sky, the way the
// real game draws them: black in the texture means "no change".
vec3 body(vec3 dir, vec3 axis, float size, out vec2 uv) {
    vec3 sx = normalize(cross(axis, vec3(0.0, 0.0, 1.0)));
    vec3 sy = cross(sx, axis);
    float d = dot(dir, axis);
    uv = vec2(-1.0);
    if (d <= 0.0) return vec3(0.0);
    vec2 q = vec2(dot(dir, sx), dot(dir, sy)) / d / size;
    if (abs(q.x) > 1.0 || abs(q.y) > 1.0) return vec3(0.0);
    uv = q * 0.5 + 0.5;
    return vec3(1.0);
}

void main() {
    vec4 eye = m_inv_pv * vec4(frag_pos.xy, 1.0, 1.0);
    vec3 dir = normalize(eye.xyz / eye.w);
    vec3 color = sky_color(dir);

    vec2 uv;
    if (body(dir, u_sun_dir, 0.24, uv).x > 0.0) {
        color += texture(u_sun_tex, uv).rgb;
    }
    if (body(dir, -u_sun_dir, 0.20, uv).x > 0.0) {
        vec2 m = vec2((floor(u_moon_phase) + uv.x) / 8.0, uv.y);
        color += texture(u_moon_tex, m).rgb * 0.95;
    }
    fragColor = vec4(color, 1.0);
}
