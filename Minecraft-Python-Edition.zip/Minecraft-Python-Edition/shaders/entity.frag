#version 330 core
#include "sky_common.glsl"

in vec2 uv;
in float shade;
in vec3 frag_world_pos;

uniform sampler2D u_tex;
uniform vec2 fog_range;
uniform vec3 cam_pos;
uniform float u_hurt;       // 1 right after a hit, fading to 0: the red flash

out vec4 fragColor;

void main() {
    vec4 texel = texture(u_tex, uv);
    if (texel.a < 0.1) discard;
    vec3 color = texel.rgb * shade;
    color = mix(color, vec3(1.0, 0.15, 0.1), u_hurt * 0.55);
    color *= mix(vec3(0.16, 0.18, 0.28), vec3(1.0), u_daylight);

    vec3 to_frag = frag_world_pos - cam_pos;
    float d = length(to_frag);
    float fog = clamp((d - fog_range.x) / (fog_range.y - fog_range.x), 0.0, 1.0);
    fog *= fog;
    if (fog > 0.0) color = mix(color, sky_color(to_frag / d), fog);
    fragColor = vec4(color, 1.0);
}
