#version 330 core
#include "sky_common.glsl"

// A dropped item: a little block (six faces from the block texture array) or
// a flat sprite — an item's own texture, or a non-cube block's icon layer.
in vec2 uv;
flat in int face;
in vec3 frag_world_pos;

uniform int u_mode;               // 0 cube, 1 item texture, 2 flat block layer
uniform sampler2DArray u_blocks;
uniform sampler2D u_tex;
uniform float u_layers[6];
uniform vec2 fog_range;
uniform vec3 cam_pos;

out vec4 fragColor;

const float SHADE[6] = float[6](1.0, 0.5, 0.8, 0.8, 0.65, 0.65);

void main() {
    vec4 texel;
    float shade = 1.0;
    if (u_mode == 0) {
        texel = texture(u_blocks, vec3(uv, u_layers[face]));
        shade = SHADE[face];
    } else if (u_mode == 1) {
        texel = texture(u_tex, uv);
    } else {
        texel = texture(u_blocks, vec3(uv, u_layers[0]));
    }
    if (texel.a < 0.1) discard;
    vec3 color = texel.rgb * shade;
    color *= mix(vec3(0.16, 0.18, 0.28), vec3(1.0), u_daylight);
    vec3 to_frag = frag_world_pos - cam_pos;
    float d = length(to_frag);
    float fog = clamp((d - fog_range.x) / (fog_range.y - fog_range.x), 0.0, 1.0);
    fog *= fog;
    if (fog > 0.0) color = mix(color, sky_color(to_frag / d), fog);
    fragColor = vec4(color, 1.0);
}
