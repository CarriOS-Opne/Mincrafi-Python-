// The terrain fragment shader's body, shared by the two passes that draw
// chunks: `chunk.frag` (opaque) and `chunk_alpha.frag` (see-through blocks).
// They differ in four lines at the end of main(); everything that decides what
// a block looks like — face lighting, the underwater tint, the saturation
// boost, the fog — lives here, once, so the two passes cannot drift apart and a
// pane of glass cannot fog differently from the wall it is set into.
//
// Requires sky_common.glsl to be included first (for sky_color).
// Resolved by ShaderManager, not by the driver: GLSL 330 has no #include.

in vec3 uv;
in float shading;
flat in int tint_class;
in vec3 frag_world_pos;

// Biome colours around the player, one texel per 4 blocks, blurred and read
// with linear filtering so biomes blend into each other (game/biomes.py).
uniform sampler2D u_grass_map;
uniform sampler2D u_foliage_map;
uniform vec4 u_biome_rect;     // xz of the map's first texel centre, world span, texel count

// The atlas has grass and leaves already painted in the plains colours, so a
// biome's colour is applied as its ratio to those.
const vec3 PLAINS_GRASS = vec3(0.569, 0.741, 0.349);
const vec3 PLAINS_FOLIAGE = vec3(0.467, 0.671, 0.184);

vec3 biome_tint(vec3 texel) {
    if (tint_class == 0 || u_biome_rect.z <= 0.0) return vec3(1.0);
    vec2 cell = (frag_world_pos.xz - u_biome_rect.xy) / u_biome_rect.z * (u_biome_rect.w - 1.0);
    vec2 tuv = (cell + 0.5) / u_biome_rect.w;
    if (tint_class == 2) return texture(u_foliage_map, tuv).rgb / PLAINS_FOLIAGE;
    vec3 t = texture(u_grass_map, tuv).rgb / PLAINS_GRASS;
    if (tint_class == 3 && !(texel.g > texel.r * 1.08 && texel.g > texel.b)) return vec3(1.0);
    return t;
}

uniform sampler2DArray u_texture_0;
uniform float water_line; // Water level for underwater effects
uniform vec2 fog_range;   // (start, fully opaque) in world units, render distance driven
uniform vec3 cam_pos;     // Eye position, for radial (spherical) fog

out vec4 fragColor;

uniform sampler2DShadow u_shadow_map;
uniform mat4 m_light;
uniform float u_shadow_strength;   // 0 = shadows off (night, or the setting)
uniform vec3 u_light_dir;          // toward the sun

// How much of the sun reaches this fragment, 0..1, from the depth map the
// renderer draws as the sun sees the world. 3x3 PCF for soft-ish edges, and
// faded out toward the edge of the mapped square so it never ends in a line.
float sun_visibility(vec3 p, vec3 n) {
    vec4 ls = m_light * vec4(p + n * 0.06, 1.0);
    vec3 c = ls.xyz / ls.w * 0.5 + 0.5;
    if (c.x <= 0.0 || c.x >= 1.0 || c.y <= 0.0 || c.y >= 1.0 || c.z >= 1.0) return 1.0;
    vec2 texel = 1.0 / vec2(textureSize(u_shadow_map, 0));
    float sum = 0.0;
    for (int x = -1; x <= 1; x++)
        for (int y = -1; y <= 1; y++)
            sum += texture(u_shadow_map, vec3(c.xy + vec2(x, y) * texel, c.z - 0.0004));
    vec2 e = abs(c.xy * 2.0 - 1.0);
    return mix(sum / 9.0, 1.0, smoothstep(0.8, 1.0, max(e.x, e.y)));
}

// Nearest-neighbour magnification done here instead of by the sampler — the
// reference's `sampleNearest` (`referans/.../shaders/core/terrain.fsh`, and the
// answer referans.md points at for this).
//
// A NEAREST sampler picks exactly one texel per fragment, so the boundary
// between two texels lands wholly inside one pixel or the other. Walk forward
// and that boundary jumps a pixel at a time, in step across a whole wall of
// repeating blocks — which is the crawling distortion you only see while
// moving. This snaps the UV to the texel centre exactly as NEAREST does, then
// backs the snap off over the last screen pixel of the texel, so the edge
// resolves instead of jumping. Up close the block stays hard-edged; the only
// thing that changes is that its edges stop crawling.
//
// It needs a LINEAR sampler — the hardware's bilinear tap is what draws that
// one-pixel ramp, so `create_texture_array` sets the filter accordingly. The
// HUD keeps NEAREST through its own sampler object: an icon is magnified 3x
// with no derivatives worth the name, and there LINEAR is just blur.
vec4 sample_nearest(vec3 uvw) {
    vec2 texel = 1.0 / vec2(textureSize(u_texture_0, 0).xy);
    vec2 du = dFdx(uvw.xy);
    vec2 dv = dFdy(uvw.xy);
    // One screen pixel, measured in uv units. Guarded because a degenerate
    // quad gives a zero derivative and the ratio below would be 0/0.
    vec2 pixel = max(sqrt(du * du + dv * dv), vec2(1e-8));

    vec2 coord = uvw.xy / texel;
    vec2 center = round(coord) - 0.5;
    vec2 offset = clamp((coord - center - 0.5) * texel / pixel + 0.5, 0.0, 1.0);
    return textureGrad(u_texture_0, vec3((center + offset) * texel, uvw.z), du, dv);
}

// Colour and coverage for one terrain texel. Alpha comes back as 1.0 for
// anything the atlas baked opaque, so the opaque pass can ignore it entirely.
vec4 shade_terrain(vec4 texel) {
    vec3 tex_color = texel.rgb * biome_tint(texel.rgb);

    // OPTIMIZATION: Removed gamma correction (2× pow operations)
    // Textures are already in sRGB, modern displays handle this

    // Apply shading (ambient occlusion + face lighting)
    // Enhanced Cinematic Tint: More vibrant warm sun and cooler shadows
    vec3 sunlight = vec3(1.08, 1.02, 0.96); // Warmer, more golden sunlight
    vec3 shadow = vec3(0.62, 0.68, 0.76);   // Slightly brighter shadows for more visibility

    // OPTIMIZATION: Replaced smoothstep with simple remap
    // shading varies from 0.4 (darkest) to 1.0 (brightest)
    float light_factor = (shading - 0.4) / 0.6; // Remap [0.4, 1.0] → [0.0, 1.0]
    light_factor = clamp(light_factor, 0.0, 1.0);
    vec3 light_tint = mix(shadow, sunlight, light_factor);

    tex_color *= shading * light_tint;

    // Sun and shadow. The face normal comes from the screen-space derivatives
    // of the world position, so the mesh needs no normal attribute.
    if (u_shadow_strength > 0.0) {
        vec3 n = normalize(cross(dFdx(frag_world_pos), dFdy(frag_world_pos)));
        if (dot(n, cam_pos - frag_world_pos) < 0.0) n = -n;
        float facing = smoothstep(-0.02, 0.22, dot(n, u_light_dir));
        float lit = facing > 0.0 ? facing * sun_visibility(frag_world_pos, n) : 0.0;
        vec3 sun = vec3(1.08, 1.06, 1.02);
        vec3 shade = vec3(0.58, 0.63, 0.76);
        tex_color *= mix(vec3(1.0), mix(shade, sun, lit), u_shadow_strength);
    }

    // Day/night: the world dims toward a cool moonlit floor at midnight rather
    // than going black, so a night is still playable without torches.
    tex_color *= mix(vec3(0.16, 0.18, 0.28), vec3(1.0), u_daylight);

    // Underwater effect - lighter, less intense blue tint
    if (frag_world_pos.y < water_line) {
        tex_color *= vec3(0.35, 0.55, 0.85); // Lighter underwater (was 0.0, 0.3, 1.0)
    }

    // Saturation boost happens BEFORE the fog mix: after it, it also pushed the
    // fog colour away from the sky's, which is what made distant terrain read as
    // a brighter silhouette than the sky behind it.
    // (very cheap: 1 dot + 1 mix)
    float gray = dot(tex_color, vec3(0.299, 0.587, 0.114));
    tex_color = mix(vec3(gray), tex_color, 1.08); // Slight saturation boost

    // Fog is tied to the render distance (fog_range), so chunks fade into the sky
    // instead of popping in at the edge. The squared ramp keeps everything up to
    // fog_range.x clear and piles the haze up over the last stretch.
    //
    // Distance is radial (from the eye), like Minecraft's spherical fog — NOT
    // gl_FragCoord.z/w, which is depth along the view axis: that made the fog on
    // a fixed piece of terrain thin out as you turned and it slid to the edge of
    // the screen, because its z-depth shrinks by cos(angle off centre).
    vec3 to_frag = frag_world_pos - cam_pos;
    float fog_dist = length(to_frag);
    float fog_factor = clamp((fog_dist - fog_range.x) / (fog_range.y - fog_range.x),
                             0.0, 1.0);
    fog_factor *= fog_factor;

    // Fog colour is the sky colour along this same ray, from the same function
    // sky.frag draws with — gradient, clouds and sun. A flat colour could only
    // match the sky at one height; the gradient alone could only match it where
    // there is no cloud, so a half-fogged mountain used to cut a cloud in half.
    // Skipped entirely below fog_range.x, which is most of the screen.
    float alpha = texel.a;
    if (fog_factor > 0.0) {
        tex_color = mix(tex_color, sky_color(to_frag / fog_dist), fog_factor);
        // Glass goes opaque as it fogs, the same way distant water does. Left
        // translucent, a fogged window blends the sky over the sky and stays a
        // visibly paler rectangle against it.
        alpha = mix(alpha, 1.0, fog_factor);
    }

    return vec4(tex_color, alpha);
}
